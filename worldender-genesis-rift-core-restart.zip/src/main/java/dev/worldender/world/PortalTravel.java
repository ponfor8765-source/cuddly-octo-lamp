package dev.worldender.world;

import dev.worldender.WorldEnder;
import dev.worldender.blast.Fx;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Teleports players between the overworld crater gate and the Genesis dimension (done at the end of the tick). */
public final class PortalTravel {
    private static final Map<UUID, ServerPlayer> PENDING = new LinkedHashMap<>();
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();

    private PortalTravel() {}

    public static void queue(ServerPlayer player) {
        PENDING.put(player.getUUID(), player);
    }

    public static void clear() {
        PENDING.clear();
        COOLDOWN.clear();
    }

    public static void processQueue(MinecraftServer server) {
        if (PENDING.isEmpty()) {
            return;
        }
        long now = server.getTickCount();
        List<ServerPlayer> list = new ArrayList<>(PENDING.values());
        PENDING.clear();
        COOLDOWN.values().removeIf(t -> t < now - 400L);
        for (ServerPlayer p : list) {
            Long until = COOLDOWN.get(p.getUUID());
            if ((until != null && until > now) || p.isRemoved() || !p.isAlive()) {
                continue;
            }
            COOLDOWN.put(p.getUUID(), now + 100L);
            if (p.serverLevel().dimension() == WorldEnder.GENESIS) {
                toOverworld(server, p);
            } else {
                toGenesis(server, p);
            }
        }
    }

    private static void toGenesis(MinecraftServer server, ServerPlayer p) {
        ServerLevel genesis = server.getLevel(WorldEnder.GENESIS);
        if (genesis == null) {
            p.displayClientMessage(Component.translatable("message.worldender.no_dimension"), false);
            return;
        }
        BlockPos at = p.blockPosition();
        BlockPos base = GateBuilder.ensureGenesisGate(genesis, at.getX(), at.getZ());
        arrive(p, genesis, base);
    }

    private static void toOverworld(MinecraftServer server, ServerPlayer p) {
        ServerLevel overworld = server.overworld();
        BlockPos at = p.blockPosition();
        overworld.getChunk(at.getX() >> 4, at.getZ() >> 4);
        BlockPos base = GateBuilder.findPortal(overworld, at.getX(), at.getZ(), 8);
        if (base != null) {
            arrive(p, overworld, base);
            return;
        }
        BlockPos spawn = overworld.getSharedSpawnPos();
        overworld.getChunk(spawn.getX() >> 4, spawn.getZ() >> 4);
        BlockPos top = overworld.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn);
        p.teleportTo(overworld, top.getX() + 0.5, top.getY(), top.getZ() + 0.5, p.getYRot(), 0.0F);
        p.displayClientMessage(Component.translatable("message.worldender.gate_lost"), false);
    }

    private static void arrive(ServerPlayer p, ServerLevel level, BlockPos base) {
        double x = base.getX() + 0.5;
        double z = base.getZ() + 3.5;
        p.teleportTo(level, x, base.getY(), z, 180.0F, 0.0F);
        p.fallDistance = 0.0F;
        level.playSound(null, x, base.getY(), z, Fx.sound("block.portal.travel"), SoundSource.PLAYERS, 0.7F, 1.0F);
    }
}
