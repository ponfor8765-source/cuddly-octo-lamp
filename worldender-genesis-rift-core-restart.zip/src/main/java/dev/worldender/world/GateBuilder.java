package dev.worldender.world;

import dev.worldender.block.GenesisPortalBlock;
import dev.worldender.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import org.jetbrains.annotations.Nullable;

/** Builds and finds Genesis gates (the portal structure). */
public final class GateBuilder {
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    private GateBuilder() {}

    /**
     * @param base bottom-centre block of the portal opening (the platform is built one block below it)
     */
    public static void build(ServerLevel level, BlockPos base, boolean clearSpace) {
        BlockState bricks = ModBlocks.GENESIS_BRICKS.get().defaultBlockState();
        BlockState lumen = ModBlocks.LUMENITE_BLOCK.get().defaultBlockState();
        BlockState portal = ModBlocks.GENESIS_PORTAL.get().defaultBlockState()
                .setValue(GenesisPortalBlock.AXIS, Direction.Axis.X);
        BlockState air = Blocks.AIR.defaultBlockState();

        if (clearSpace) {
            for (int dx = -6; dx <= 6; dx++) {
                for (int dz = -6; dz <= 6; dz++) {
                    for (int dy = 0; dy <= 12; dy++) {
                        set(level, base.offset(dx, dy, dz), air);
                    }
                }
            }
        }
        // platform
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                set(level, base.offset(dx, -1, dz), bricks);
                set(level, base.offset(dx, -2, dz), bricks);
                if (Math.abs(dx) == 5 && Math.abs(dz) == 5) {
                    set(level, base.offset(dx, 0, dz), lumen);
                    set(level, base.offset(dx, 1, dz), lumen);
                }
            }
        }
        // frame: two pillars and a top beam
        for (int dy = 0; dy <= 7; dy++) {
            BlockState s = (dy == 3) ? lumen : bricks;
            set(level, base.offset(-3, dy, 0), s);
            set(level, base.offset(3, dy, 0), s);
        }
        for (int dx = -3; dx <= 3; dx++) {
            set(level, base.offset(dx, 7, 0), bricks);
        }
        set(level, base.offset(-3, 8, 0), lumen);
        set(level, base.offset(3, 8, 0), lumen);
        // the portal itself: 5 wide, 7 tall
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = 0; dy <= 6; dy++) {
                set(level, base.offset(dx, dy, 0), portal);
            }
        }
    }

    private static void set(ServerLevel level, BlockPos pos, BlockState state) {
        if (level.getBlockState(pos) != state) {
            level.setBlock(pos, state, FLAGS);
        }
    }

    /** Finds an existing gate in the Genesis dimension at (x, z) or builds a new one on the surface. */
    public static BlockPos ensureGenesisGate(ServerLevel genesis, int x, int z) {
        genesis.getChunk(x >> 4, z >> 4);
        BlockPos existing = findPortal(genesis, x, z, 0);
        if (existing != null) {
            return existing;
        }
        int top = genesis.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        int y = Math.max(top, genesis.getSeaLevel() + 1);
        BlockPos base = new BlockPos(x, y, z);
        build(genesis, base, true);
        return base;
    }

    /** Searches columns around (x, z), nearest first, and returns the bottom portal block of the first gate found. */
    @Nullable
    public static BlockPos findPortal(ServerLevel level, int x, int z, int range) {
        Block portal = ModBlocks.GENESIS_PORTAL.get();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int r = 0; r <= range; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) {
                        continue;
                    }
                    int px = x + dx;
                    int pz = z + dz;
                    level.getChunk(px >> 4, pz >> 4);
                    int top = level.getHeight(Heightmap.Types.WORLD_SURFACE, px, pz) + 2;
                    int bottom = Math.max(level.getMinBuildHeight(), top - 60);
                    for (int y = top; y >= bottom; y--) {
                        if (level.getBlockState(p.set(px, y, pz)).is(portal)) {
                            int yy = y;
                            while (level.getBlockState(p.set(px, yy - 1, pz)).is(portal)) {
                                yy--;
                            }
                            return new BlockPos(px, yy, pz);
                        }
                    }
                }
            }
        }
        return null;
    }
}
