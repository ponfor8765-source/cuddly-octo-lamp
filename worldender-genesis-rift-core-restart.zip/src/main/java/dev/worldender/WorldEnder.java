package dev.worldender;

import dev.worldender.event.CommonEvents;
import dev.worldender.registry.ModBlockEntities;
import dev.worldender.registry.ModBlocks;
import dev.worldender.registry.ModCreativeTabs;
import dev.worldender.registry.ModEntities;
import dev.worldender.registry.ModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;

@Mod(WorldEnder.MOD_ID)
public class WorldEnder {
    public static final String MOD_ID = "worldender";

    /** The new dimension, defined in data/worldender/dimension/genesis.json */
    public static final ResourceKey<Level> GENESIS = ResourceKey.create(Registries.DIMENSION, id("genesis"));

    public WorldEnder(IEventBus modBus, ModContainer container) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);

        modBus.addListener(CommonEvents::registerAttributes);
        modBus.addListener(CommonEvents::registerSpawnPlacements);
        modBus.addListener(CommonEvents::registerPayloads);

        NeoForge.EVENT_BUS.addListener(CommonEvents::onServerTick);
        NeoForge.EVENT_BUS.addListener(CommonEvents::onServerStopping);

        if (FMLEnvironment.dist == Dist.CLIENT) {
            dev.worldender.client.ClientSetup.init(modBus);
        }
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }
}
