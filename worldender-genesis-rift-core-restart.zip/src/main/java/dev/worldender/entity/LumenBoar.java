package dev.worldender.entity;

import dev.worldender.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.level.Level;

/** A glowing boar of Genesis. Behaves like a pig. */
public class LumenBoar extends Pig {
    public LumenBoar(EntityType<? extends LumenBoar> type, Level level) {
        super(type, level);
    }

    @Override
    public Pig getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return ModEntities.LUMEN_BOAR.get().create(level);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide && random.nextInt(8) == 0) {
            level().addParticle(ParticleTypes.GLOW, getRandomX(0.6), getRandomY(), getRandomZ(0.6), 0.0, 0.02, 0.0);
        }
    }
}
