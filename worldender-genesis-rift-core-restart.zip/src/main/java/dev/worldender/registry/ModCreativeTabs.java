package dev.worldender.registry;

import dev.worldender.WorldEnder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, WorldEnder.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.worldender"))
                    .icon(() -> new ItemStack(ModItems.GENESIS_RIFT_CORE.get()))
                    .displayItems((params, output) ->
                            ModItems.ITEMS.getEntries().forEach(h -> output.accept(h.get())))
                    .build());

    private ModCreativeTabs() {}
}
