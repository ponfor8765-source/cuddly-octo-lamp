package dev.worldender.registry;

import dev.worldender.WorldEnder;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(WorldEnder.MOD_ID);

    public static final DeferredItem<BlockItem> GENESIS_RIFT_CORE = ITEMS.registerSimpleBlockItem("genesis_rift_core",
            ModBlocks.GENESIS_RIFT_CORE, new Item.Properties().rarity(Rarity.EPIC).stacksTo(1));
    public static final DeferredItem<BlockItem> GENESIS_BRICKS = ITEMS.registerSimpleBlockItem("genesis_bricks", ModBlocks.GENESIS_BRICKS);
    public static final DeferredItem<BlockItem> GENESIS_STONE = ITEMS.registerSimpleBlockItem("genesis_stone", ModBlocks.GENESIS_STONE);
    public static final DeferredItem<BlockItem> GENESIS_SOIL = ITEMS.registerSimpleBlockItem("genesis_soil", ModBlocks.GENESIS_SOIL);
    public static final DeferredItem<BlockItem> GLOW_GRASS_BLOCK = ITEMS.registerSimpleBlockItem("glow_grass_block", ModBlocks.GLOW_GRASS_BLOCK);
    public static final DeferredItem<BlockItem> LUMENITE_BLOCK = ITEMS.registerSimpleBlockItem("lumenite_block", ModBlocks.LUMENITE_BLOCK);
    public static final DeferredItem<BlockItem> LUMENITE_ORE = ITEMS.registerSimpleBlockItem("lumenite_ore", ModBlocks.LUMENITE_ORE);
    public static final DeferredItem<BlockItem> VOIDSTEEL_ORE = ITEMS.registerSimpleBlockItem("voidsteel_ore", ModBlocks.VOIDSTEEL_ORE);
    public static final DeferredItem<BlockItem> AURORITE_ORE = ITEMS.registerSimpleBlockItem("aurorite_ore", ModBlocks.AURORITE_ORE);
    public static final DeferredItem<BlockItem> LUMEN_LOG = ITEMS.registerSimpleBlockItem("lumen_log", ModBlocks.LUMEN_LOG);
    public static final DeferredItem<BlockItem> LUMEN_LEAVES = ITEMS.registerSimpleBlockItem("lumen_leaves", ModBlocks.LUMEN_LEAVES);
    public static final DeferredItem<BlockItem> GLOW_BLOOM = ITEMS.registerSimpleBlockItem("glow_bloom", ModBlocks.GLOW_BLOOM);

    public static final DeferredItem<Item> LUMENITE_GEM = ITEMS.registerSimpleItem("lumenite_gem");
    public static final DeferredItem<Item> RAW_VOIDSTEEL = ITEMS.registerSimpleItem("raw_voidsteel");
    public static final DeferredItem<Item> VOIDSTEEL_INGOT = ITEMS.registerSimpleItem("voidsteel_ingot");
    public static final DeferredItem<Item> AURORITE_SHARD = ITEMS.registerSimpleItem("aurorite_shard");

    public static final DeferredItem<SwordItem> VOIDSTEEL_SWORD = ITEMS.register("voidsteel_sword",
            () -> new SwordItem(ModTiers.VOIDSTEEL,
                    new Item.Properties().attributes(SwordItem.createAttributes(ModTiers.VOIDSTEEL, 3, -2.4F))));
    public static final DeferredItem<PickaxeItem> VOIDSTEEL_PICKAXE = ITEMS.register("voidsteel_pickaxe",
            () -> new PickaxeItem(ModTiers.VOIDSTEEL,
                    new Item.Properties().attributes(PickaxeItem.createAttributes(ModTiers.VOIDSTEEL, 1.0F, -2.8F))));

    public static final DeferredItem<DeferredSpawnEggItem> VOID_STALKER_SPAWN_EGG = ITEMS.register("void_stalker_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.VOID_STALKER, 0x14081f, 0xb040ff, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> LUMEN_BOAR_SPAWN_EGG = ITEMS.register("lumen_boar_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.LUMEN_BOAR, 0x2a6f6f, 0x7dffe0, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> AURORA_SPIDER_SPAWN_EGG = ITEMS.register("aurora_spider_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.AURORA_SPIDER, 0x101030, 0x40ffb0, new Item.Properties()));

    private ModItems() {}
}
