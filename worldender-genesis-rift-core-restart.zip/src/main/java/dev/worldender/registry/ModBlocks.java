package dev.worldender.registry;

import dev.worldender.WorldEnder;
import dev.worldender.block.GenesisRiftCoreBlock;
import dev.worldender.block.GenesisPortalBlock;
import dev.worldender.block.GlowBloomBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(WorldEnder.MOD_ID);

    public static final DeferredBlock<GenesisRiftCoreBlock> GENESIS_RIFT_CORE = BLOCKS.registerBlock("genesis_rift_core",
            GenesisRiftCoreBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(8.0F, 1200.0F)
                    .sound(SoundType.METAL).requiresCorrectToolForDrops()
                    .lightLevel(s -> s.getValue(GenesisRiftCoreBlock.ARMED) ? 15 : 6));

    public static final DeferredBlock<GenesisPortalBlock> GENESIS_PORTAL = BLOCKS.registerBlock("genesis_portal",
            GenesisPortalBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).noCollission().noOcclusion()
                    .strength(-1.0F, 3600000.0F).noLootTable().lightLevel(s -> 15)
                    .pushReaction(PushReaction.BLOCK));

    public static final DeferredBlock<Block> GENESIS_BRICKS = BLOCKS.registerSimpleBlock("genesis_bricks",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(30.0F, 1200.0F)
                    .sound(SoundType.DEEPSLATE_BRICKS).requiresCorrectToolForDrops());

    public static final DeferredBlock<Block> GENESIS_STONE = BLOCKS.registerSimpleBlock("genesis_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(2.0F, 7.0F)
                    .sound(SoundType.DEEPSLATE).requiresCorrectToolForDrops());

    public static final DeferredBlock<Block> GENESIS_SOIL = BLOCKS.registerSimpleBlock("genesis_soil",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(0.6F).sound(SoundType.GRAVEL));

    public static final DeferredBlock<Block> GLOW_GRASS_BLOCK = BLOCKS.registerSimpleBlock("glow_grass_block",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_GREEN).strength(0.6F)
                    .sound(SoundType.GRASS).lightLevel(s -> 5));

    public static final DeferredBlock<Block> LUMENITE_BLOCK = BLOCKS.registerSimpleBlock("lumenite_block",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(3.0F, 6.0F)
                    .sound(SoundType.AMETHYST).lightLevel(s -> 12).requiresCorrectToolForDrops());

    public static final DeferredBlock<Block> LUMENITE_ORE = BLOCKS.registerSimpleBlock("lumenite_ore",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(3.0F, 3.0F)
                    .sound(SoundType.DEEPSLATE).lightLevel(s -> 8).requiresCorrectToolForDrops());

    public static final DeferredBlock<Block> VOIDSTEEL_ORE = BLOCKS.registerSimpleBlock("voidsteel_ore",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(3.5F, 3.0F)
                    .sound(SoundType.DEEPSLATE).requiresCorrectToolForDrops());

    public static final DeferredBlock<Block> AURORITE_ORE = BLOCKS.registerSimpleBlock("aurorite_ore",
            BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).strength(4.5F, 3.0F)
                    .sound(SoundType.DEEPSLATE).lightLevel(s -> 6).requiresCorrectToolForDrops());

    public static final DeferredBlock<RotatedPillarBlock> LUMEN_LOG = BLOCKS.registerBlock("lumen_log",
            RotatedPillarBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(2.0F)
                    .sound(SoundType.WOOD).lightLevel(s -> 4));

    public static final DeferredBlock<LeavesBlock> LUMEN_LEAVES = BLOCKS.registerBlock("lumen_leaves",
            LeavesBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE).strength(0.2F).randomTicks()
                    .sound(SoundType.AZALEA_LEAVES).noOcclusion().lightLevel(s -> 9)
                    .isSuffocating((s, g, p) -> false).isViewBlocking((s, g, p) -> false));

    public static final DeferredBlock<GlowBloomBlock> GLOW_BLOOM = BLOCKS.registerBlock("glow_bloom",
            GlowBloomBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).noCollission().instabreak()
                    .sound(SoundType.GRASS).lightLevel(s -> 11).pushReaction(PushReaction.DESTROY));

    private ModBlocks() {}
}
