package dev.worldender.registry;

import dev.worldender.WorldEnder;
import dev.worldender.block.GenesisRiftCoreBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, WorldEnder.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GenesisRiftCoreBlockEntity>> GENESIS_RIFT_CORE =
            BLOCK_ENTITIES.register("genesis_rift_core",
                    () -> BlockEntityType.Builder.of(GenesisRiftCoreBlockEntity::new, ModBlocks.GENESIS_RIFT_CORE.get()).build(null));

    private ModBlockEntities() {}
}
