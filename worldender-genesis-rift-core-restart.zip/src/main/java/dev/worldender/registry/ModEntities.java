package dev.worldender.registry;

import dev.worldender.WorldEnder;
import dev.worldender.entity.AuroraSpider;
import dev.worldender.entity.LumenBoar;
import dev.worldender.entity.VoidStalker;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, WorldEnder.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<VoidStalker>> VOID_STALKER = ENTITIES.register("void_stalker",
            () -> EntityType.Builder.of(VoidStalker::new, MobCategory.MONSTER).sized(0.6F, 2.5F)
                    .clientTrackingRange(8).build("void_stalker"));

    public static final DeferredHolder<EntityType<?>, EntityType<LumenBoar>> LUMEN_BOAR = ENTITIES.register("lumen_boar",
            () -> EntityType.Builder.of(LumenBoar::new, MobCategory.CREATURE).sized(0.9F, 0.9F)
                    .clientTrackingRange(10).build("lumen_boar"));

    public static final DeferredHolder<EntityType<?>, EntityType<AuroraSpider>> AURORA_SPIDER = ENTITIES.register("aurora_spider",
            () -> EntityType.Builder.of(AuroraSpider::new, MobCategory.MONSTER).sized(1.4F, 0.9F)
                    .clientTrackingRange(8).build("aurora_spider"));

    private ModEntities() {}
}
