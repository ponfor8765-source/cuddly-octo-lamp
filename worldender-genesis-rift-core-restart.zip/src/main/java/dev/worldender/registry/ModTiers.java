package dev.worldender.registry;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.common.SimpleTier;

public final class ModTiers {
    public static final Tier VOIDSTEEL = new SimpleTier(
            BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 2200, 8.5F, 3.5F, 15,
            () -> Ingredient.of(ModItems.VOIDSTEEL_INGOT.get()));

    private ModTiers() {}
}
