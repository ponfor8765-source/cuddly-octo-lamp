package dev.worldender.client;

import dev.worldender.WorldEnder;
import dev.worldender.entity.AuroraSpider;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.SpiderRenderer;
import net.minecraft.resources.ResourceLocation;

public class AuroraSpiderRenderer extends SpiderRenderer<AuroraSpider> {
    private static final ResourceLocation TEXTURE = WorldEnder.id("textures/entity/aurora_spider.png");

    public AuroraSpiderRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(AuroraSpider entity) {
        return TEXTURE;
    }
}
