package dev.worldender.client;

import dev.worldender.WorldEnder;
import dev.worldender.entity.VoidStalker;
import net.minecraft.client.model.EndermanModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class VoidStalkerRenderer extends MobRenderer<VoidStalker, EndermanModel<VoidStalker>> {
    private static final ResourceLocation TEXTURE = WorldEnder.id("textures/entity/void_stalker.png");

    public VoidStalkerRenderer(EntityRendererProvider.Context context) {
        super(context, new EndermanModel<>(context.bakeLayer(ModelLayers.ENDERMAN)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(VoidStalker entity) {
        return TEXTURE;
    }
}
