package dev.worldender.client;

import dev.worldender.net.BlastEffectPayload;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ViewportEvent;

/** Client-side state for the camera shake and the white flash. */
public final class ClientEffects {
    private static BlockPos shakeOrigin = BlockPos.ZERO;
    private static long shakeUntil;
    private static float shakeIntensity;
    private static BlockPos flashOrigin = BlockPos.ZERO;
    private static long flashStart;
    private static long flashEnd;

    private ClientEffects() {}

    public static void handle(BlastEffectPayload payload) {
        long now = System.currentTimeMillis();
        if (payload.kind() == BlastEffectPayload.SHAKE) {
            shakeOrigin = payload.pos();
            shakeUntil = now + payload.duration() * 50L;
            shakeIntensity = payload.intensity();
        } else {
            flashOrigin = payload.pos();
            flashStart = now;
            flashEnd = now + payload.duration() * 50L;
        }
    }

    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        long now = System.currentTimeMillis();
        if (now >= shakeUntil) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        double dist = mc.player.position().distanceTo(Vec3.atCenterOf(shakeOrigin));
        double falloff = Mth.clamp(1.0 - dist / 500.0, 0.0, 1.0);
        if (falloff <= 0.0) {
            return;
        }
        long left = shakeUntil - now;
        double fade = left < 1500L ? left / 1500.0 : 1.0;
        double amp = shakeIntensity * 0.3 * falloff * fade;
        event.setYaw((float) (event.getYaw() + (Math.random() - 0.5) * amp));
        event.setPitch((float) (event.getPitch() + (Math.random() - 0.5) * amp));
        event.setRoll((float) (event.getRoll() + (Math.random() - 0.5) * amp * 0.6));
    }

    public static void renderFlash(GuiGraphics graphics, DeltaTracker deltaTracker) {
        long now = System.currentTimeMillis();
        if (now >= flashEnd) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        if (mc.player.position().distanceTo(Vec3.atCenterOf(flashOrigin)) > 1500.0) {
            return;
        }
        float t = (now - flashStart) / (float) Math.max(1L, flashEnd - flashStart);
        float alpha = t < 0.1F ? 1.0F : 1.0F - (t - 0.1F) / 0.9F;
        alpha = Mth.clamp(alpha, 0.0F, 1.0F);
        alpha *= alpha;
        if (alpha <= 0.01F) {
            return;
        }
        int a = (int) (alpha * 255.0F);
        graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), (a << 24) | 0xFFFFFF);
    }
}
