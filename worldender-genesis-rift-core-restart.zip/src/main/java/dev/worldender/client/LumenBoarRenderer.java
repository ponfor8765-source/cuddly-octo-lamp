package dev.worldender.client;

import dev.worldender.WorldEnder;
import dev.worldender.entity.LumenBoar;
import net.minecraft.client.model.PigModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class LumenBoarRenderer extends MobRenderer<LumenBoar, PigModel<LumenBoar>> {
    private static final ResourceLocation TEXTURE = WorldEnder.id("textures/entity/lumen_boar.png");

    public LumenBoarRenderer(EntityRendererProvider.Context context) {
        super(context, new PigModel<>(context.bakeLayer(ModelLayers.PIG)), 0.7F);
    }

    @Override
    public ResourceLocation getTextureLocation(LumenBoar entity) {
        return TEXTURE;
    }
}
