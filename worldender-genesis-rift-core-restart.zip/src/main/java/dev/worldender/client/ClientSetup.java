package dev.worldender.client;

import dev.worldender.WorldEnder;
import dev.worldender.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.common.NeoForge;

public final class ClientSetup {
    private ClientSetup() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerRenderers);
        modBus.addListener(ClientSetup::registerLayers);
        NeoForge.EVENT_BUS.addListener(ClientEffects::onCamera);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.VOID_STALKER.get(), VoidStalkerRenderer::new);
        event.registerEntityRenderer(ModEntities.LUMEN_BOAR.get(), LumenBoarRenderer::new);
        event.registerEntityRenderer(ModEntities.AURORA_SPIDER.get(), AuroraSpiderRenderer::new);
    }

    private static void registerLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(WorldEnder.id("flash"), ClientEffects::renderFlash);
    }
}
