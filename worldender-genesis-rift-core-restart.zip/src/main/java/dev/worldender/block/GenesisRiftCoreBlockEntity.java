package dev.worldender.block;

import dev.worldender.Config;
import dev.worldender.blast.BlastManager;
import dev.worldender.blast.Fx;
import dev.worldender.net.BlastEffectPayload;
import dev.worldender.registry.ModBlockEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

public class GenesisRiftCoreBlockEntity extends BlockEntity {
    /** Ticks left until the Genesis pulse, -1 while the core is inactive. */
    private int countdown = -1;

    public GenesisRiftCoreBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GENESIS_RIFT_CORE.get(), pos, state);
    }

    public boolean isArmed() {
        return countdown >= 0;
    }

    public void arm(int ticks) {
        this.countdown = ticks;
        setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Countdown", countdown);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        countdown = tag.contains("Countdown") ? tag.getInt("Countdown") : -1;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, GenesisRiftCoreBlockEntity be) {
        if (be.countdown < 0 || !(level instanceof ServerLevel sl)) {
            return;
        }
        int c = be.countdown;
        int total = Math.max(1, Config.COUNTDOWN_SECONDS.get() * 20);
        float progress = 1.0F - (float) c / total;
        double x = pos.getX() + 0.5, y = pos.getY() + 0.5, z = pos.getZ() + 0.5;

        // charging spiral around the rift core
        double ang = c * 0.35;
        double rad = 1.2 + 6.0 * progress;
        sl.sendParticles(ParticleTypes.END_ROD, x + Math.cos(ang) * rad, y - 0.3, z + Math.sin(ang) * rad, 2, 0.05, 0.4, 0.05, 0.15);
        sl.sendParticles(ParticleTypes.END_ROD, x - Math.cos(ang) * rad, y - 0.3, z - Math.sin(ang) * rad, 2, 0.05, 0.4, 0.05, 0.15);
        // light beam into the sky, visible from far away
        for (int i = 0; i < 3; i++) {
            Fx.particles(sl, ParticleTypes.END_ROD, x, y + 1 + sl.random.nextInt(70), z, 1, 0.12, 0.0, 0.12, 0.0);
        }

        // beeping + blinking, faster and higher near the end
        int interval = Mth.clamp(c / 10, 2, 20);
        if (c % interval == 0) {
            sl.setBlock(pos, state.setValue(GenesisRiftCoreBlock.BLINK, !state.getValue(GenesisRiftCoreBlock.BLINK)), 3);
            sl.playSound(null, pos, Fx.sound("block.note_block.pling"), SoundSource.BLOCKS, 3.0F, 0.5F + progress * 1.5F);
        }

        // last 5 seconds: warnings, lightning, camera shake
        if (c <= 100) {
            if (c % 20 == 0 && c > 0) {
                Component msg = Component.translatable("message.worldender.countdown", c / 20).withStyle(ChatFormatting.RED);
                for (ServerPlayer p : sl.players()) {
                    p.displayClientMessage(msg, true);
                }
            }
            if (c % 12 == 0) {
                int bx = pos.getX() + sl.random.nextInt(81) - 40;
                int bz = pos.getZ() + sl.random.nextInt(81) - 40;
                if (sl.hasChunkAt(new BlockPos(bx, pos.getY(), bz))) {
                    Fx.lightning(sl, bx + 0.5, sl.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz), bz + 0.5);
                }
            }
        }
        if (c == 100) {
            Fx.send(sl, new BlastEffectPayload(pos, BlastEffectPayload.SHAKE, 100, 8));
        }
        if (c == 20) {
            Fx.send(sl, new BlastEffectPayload(pos, BlastEffectPayload.SHAKE, 20, 20));
        }

        if (c <= 0) {
            sl.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            BlastManager.start(sl, pos, Config.BLAST_RADIUS.get());
            return;
        }
        be.countdown = c - 1;
        be.setChanged();
    }
}
