package dev.worldender.block;

import com.mojang.serialization.MapCodec;
import dev.worldender.Config;
import dev.worldender.WorldEnder;
import dev.worldender.blast.Fx;
import dev.worldender.registry.ModBlockEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public class GenesisRiftCoreBlock extends BaseEntityBlock {
    public static final MapCodec<GenesisRiftCoreBlock> CODEC = simpleCodec(GenesisRiftCoreBlock::new);
    public static final BooleanProperty ARMED = BooleanProperty.create("armed");
    public static final BooleanProperty BLINK = BooleanProperty.create("blink");

    public GenesisRiftCoreBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(ARMED, false).setValue(BLINK, false));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ARMED, BLINK);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new GenesisRiftCoreBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null
                : createTickerHelper(type, ModBlockEntities.GENESIS_RIFT_CORE.get(), GenesisRiftCoreBlockEntity::serverTick);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        arm(level, pos, player);
        return InteractionResult.CONSUME;
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        if (!level.isClientSide && !oldState.is(state.getBlock()) && level.hasNeighborSignal(pos)) {
            arm(level, pos, null);
        }
    }

    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean movedByPiston) {
        if (!level.isClientSide && level.hasNeighborSignal(pos)) {
            arm(level, pos, null);
        }
    }

    /** Starts the rift-core activation sequence (server side only). */
    public static void arm(Level level, BlockPos pos, @Nullable Player who) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        if (level.dimension() == WorldEnder.GENESIS) {
            if (who != null) {
                who.displayClientMessage(Component.translatable("message.worldender.rejected"), true);
            }
            return;
        }
        if (!level.dimensionType().hasSkyLight() || level.dimensionType().hasCeiling()) {
            if (who != null) {
                who.displayClientMessage(Component.translatable("message.worldender.no_sky"), true);
            }
            return;
        }
        if (level.getBlockEntity(pos) instanceof GenesisRiftCoreBlockEntity core && !core.isArmed()) {
            core.arm(Config.COUNTDOWN_SECONDS.get() * 20);
            level.setBlock(pos, level.getBlockState(pos).setValue(ARMED, true), 3);
            level.playSound(null, pos, Fx.sound("block.beacon.activate"), SoundSource.BLOCKS, 4.0F, 0.6F);
            for (ServerPlayer p : serverLevel.players()) {
                p.displayClientMessage(Component.translatable("message.worldender.armed")
                        .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), false);
            }
        }
    }
}
