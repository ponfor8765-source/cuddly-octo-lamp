package dev.worldender.blast;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.neoforged.neoforge.network.PacketDistributor;

/** Small helpers for long-range particles, sounds and packets. */
public final class Fx {
    private Fx() {}

    public static SoundEvent sound(String path) {
        return SoundEvent.createVariableRangeEvent(ResourceLocation.withDefaultNamespace(path));
    }

    /** Sends particles to every player in the level, even very far away (up to 512 blocks). */
    public static void particles(ServerLevel level, ParticleOptions type, double x, double y, double z,
                                 int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayer p : level.players()) {
            level.sendParticles(p, type, true, x, y, z, count, dx, dy, dz, speed);
        }
    }

    public static void send(ServerLevel level, CustomPacketPayload payload) {
        PacketDistributor.sendToPlayersInDimension(level, payload);
    }

    /** Volume above 1.0 extends the audible range (range = 16 * volume blocks). */
    public static void loudSound(ServerLevel level, double x, double y, double z, String path, float volume, float pitch) {
        level.playSound(null, x, y, z, sound(path), SoundSource.AMBIENT, volume, pitch);
    }

    public static void lightning(ServerLevel level, double x, double y, double z) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(x, y, z);
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
    }
}
