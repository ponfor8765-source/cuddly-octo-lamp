package dev.worldender.blast;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Keeps track of all running blasts and ticks them once per server tick. */
public final class BlastManager {
    private static final List<Blast> ACTIVE = new ArrayList<>();

    private BlastManager() {}

    public static void start(ServerLevel level, BlockPos center, int radius) {
        ACTIVE.add(new Blast(level, center, radius));
    }

    public static void tick() {
        if (ACTIVE.isEmpty()) {
            return;
        }
        Iterator<Blast> it = ACTIVE.iterator();
        while (it.hasNext()) {
            if (it.next().tick()) {
                it.remove();
            }
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
