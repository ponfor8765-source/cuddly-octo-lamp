package dev.worldender.blast;

import dev.worldender.Config;
import dev.worldender.net.BlastEffectPayload;
import dev.worldender.world.GateBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * One Genesis pulse. The terrain is reshaped column by column, sorted by distance from the centre, so the
 * destruction travels outwards as a visible shockwave. Work per tick is time-limited to keep the server alive.
 */
final class Blast {
    private static final long BUDGET_NS = 28_000_000L;
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState OBSIDIAN = Blocks.OBSIDIAN.defaultBlockState();
    private static final BlockState CRYING = Blocks.CRYING_OBSIDIAN.defaultBlockState();
    private static final BlockState MAGMA = Blocks.MAGMA_BLOCK.defaultBlockState();
    private static final BlockState BLACKSTONE = Blocks.BLACKSTONE.defaultBlockState();
    private static final BlockState BASALT = Blocks.BASALT.defaultBlockState();
    private static final BlockState COARSE = Blocks.COARSE_DIRT.defaultBlockState();
    private static final BlockState GRAVEL = Blocks.GRAVEL.defaultBlockState();
    private static final BlockState TUFF = Blocks.TUFF.defaultBlockState();
    private static final BlockState COBBLED_DEEPSLATE = Blocks.COBBLED_DEEPSLATE.defaultBlockState();
    private static final BlockState FIRE = Blocks.FIRE.defaultBlockState();

    private final ServerLevel level;
    private final BlockPos center;
    private final int radius;
    private final int depth;
    private final double speed;
    private final double craterRadius;
    private final int groundCenter;
    private final int floorY;
    private final long[] order;
    private final Set<UUID> hit = new HashSet<>();

    private int cursor;
    private int age;
    private double wave;
    private double prevWave;
    private boolean portalBuilt;
    private int portalAge = -1;
    private int finishAt = -1;

    Blast(ServerLevel level, BlockPos center, int radius) {
        this.level = level;
        this.center = center;
        this.radius = radius;
        this.depth = Config.CRATER_DEPTH.get();
        this.speed = Config.WAVE_SPEED.get();
        this.craterRadius = Math.min(radius * 0.9, Math.max(radius * 0.32, depth * 2.2));

        int minY = level.getMinBuildHeight();
        LevelChunk cc = level.getChunk(center.getX() >> 4, center.getZ() >> 4);
        int g = findGround(cc, center.getX(), center.getZ(), center.getY() + 1);
        if (g == Integer.MIN_VALUE) {
            g = center.getY() - 1;
        }
        this.groundCenter = Math.max(g, minY + depth + 12);
        this.floorY = Math.max(minY + 8, groundCenter - depth);

        long r2 = (long) radius * radius;
        int n = 0;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if ((long) dx * dx + (long) dz * dz <= r2) {
                    n++;
                }
            }
        }
        long[] arr = new long[n];
        int i = 0;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int d2 = dx * dx + dz * dz;
                if ((long) d2 <= r2) {
                    arr[i++] = ((long) d2 << 24) | ((long) (dx + 512) << 12) | (long) (dz + 512);
                }
            }
        }
        Arrays.sort(arr);
        this.order = arr;
    }

    /** @return true when the blast is completely finished. */
    boolean tick() {
        age++;
        if (age == 1) {
            onDetonate();
        }
        if (cursor < order.length) {
            advanceTerrain();
        }
        affectEntities();
        effects();

        if (!portalBuilt && wave >= 10.0) {
            portalBuilt = true;
            portalAge = age;
            GateBuilder.build(level, new BlockPos(center.getX(), floorY + 1, center.getZ()), true);
            double x = center.getX() + 0.5, z = center.getZ() + 0.5;
            Fx.send(level, new BlastEffectPayload(center, BlastEffectPayload.FLASH, 30, 1));
            Fx.loudSound(level, x, floorY + 2, z, "block.end_portal.spawn", 60.0F, 0.7F);
            Fx.loudSound(level, x, floorY + 2, z, "entity.ender_dragon.growl", 40.0F, 0.6F);
        }
        if (cursor >= order.length && finishAt < 0) {
            finishAt = age + 240;
        }
        return finishAt >= 0 && age >= finishAt;
    }

    // ------------------------------------------------------------------ terrain

    private void advanceTerrain() {
        prevWave = wave;
        double target = wave + speed;
        double t2 = target * target;
        long deadline = System.nanoTime() + BUDGET_NS;
        int cx = center.getX();
        int cz = center.getZ();
        while (cursor < order.length) {
            long k = order[cursor];
            int d2 = (int) (k >> 24);
            if (d2 > t2) {
                break;
            }
            int dz = (int) (k & 0xFFF) - 512;
            int dx = (int) ((k >> 12) & 0xFFF) - 512;
            processColumn(cx + dx, cz + dz, Math.sqrt(d2));
            cursor++;
            if ((cursor & 7) == 0 && System.nanoTime() > deadline) {
                break;
            }
        }
        wave = cursor < order.length ? Math.min(target, Math.sqrt((int) (order[cursor] >> 24))) : target;
    }

    private void processColumn(int x, int z, double d) {
        LevelChunk chunk = level.getChunk(x >> 4, z >> 4);
        int lx = x & 15;
        int lz = z & 15;
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight();
        int topY = Math.min(maxY - 1, chunk.getHeight(Heightmap.Types.WORLD_SURFACE, lx, lz) + 1);
        if (topY <= minY) {
            return;
        }
        int ground = findGround(chunk, x, z, topY);
        if (ground == Integer.MIN_VALUE) {
            ground = groundCenter;
        }

        int cut;
        if (d < craterRadius) {
            double c = Math.max(0.0, (d - 6.0) / Math.max(1.0, craterRadius - 6.0));
            int bowl = groundCenter - (int) Math.round(depth * Math.pow(1.0 - c, 1.35));
            cut = Math.min(bowl, ground);
        } else {
            double s = (d - craterRadius) / Math.max(1.0, radius - craterRadius);
            int shave = 1 + (int) Math.round(3.0 * (1.0 - s));
            cut = ground - shave;
        }
        cut = Math.max(cut, minY + 1);

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int y = topY; y > cut; y--) {
            pos.set(x, y, z);
            if (!chunk.getBlockState(pos).isAir()) {
                level.setBlock(pos, AIR, FLAGS);
            }
        }

        double f = d / radius;
        int h = hash(x, z);
        pos.set(x, cut, z);
        BlockState top = chunk.getBlockState(pos);
        if (!top.isAir() && top.getFluidState().isEmpty()) {
            level.setBlock(pos, scorch(f, h), FLAGS);
            if (f < 0.12) {
                pos.set(x, cut - 1, z);
                if (!chunk.getBlockState(pos).isAir()) {
                    level.setBlock(pos, scorch(f, h >>> 7), FLAGS);
                }
            }
            if (f < 0.75 && Math.floorMod(h >>> 11, 90) == 0) {
                pos.set(x, cut + 1, z);
                level.setBlock(pos, FIRE, FLAGS);
            }
        }
    }

    private static boolean isNatural(BlockState s) {
        return s.is(BlockTags.DIRT) || s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.SAND)
                || s.is(BlockTags.TERRACOTTA) || s.is(Blocks.GRAVEL) || s.is(Blocks.CLAY)
                || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.ICE) || s.is(Blocks.PACKED_ICE)
                || s.is(Blocks.SANDSTONE) || s.is(Blocks.RED_SANDSTONE);
    }

    /** Highest natural terrain block at or below startY (skips trees and buildings). */
    private static int findGround(LevelChunk chunk, int x, int z, int startY) {
        int minY = chunk.getMinBuildHeight();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int y = startY; y >= minY; y--) {
            if (isNatural(chunk.getBlockState(pos.set(x, y, z)))) {
                return y;
            }
        }
        return Integer.MIN_VALUE;
    }

    private static BlockState scorch(double f, int h) {
        int r = Math.floorMod(h, 100);
        if (f < 0.06) {
            return r < 60 ? OBSIDIAN : r < 85 ? CRYING : MAGMA;
        }
        if (f < 0.34) {
            return r < 40 ? BLACKSTONE : r < 65 ? BASALT : r < 78 ? MAGMA : r < 92 ? OBSIDIAN : TUFF;
        }
        return r < 45 ? COARSE : r < 65 ? BLACKSTONE : r < 80 ? GRAVEL : r < 90 ? TUFF : COBBLED_DEEPSLATE;
    }

    private static int hash(int x, int z) {
        int h = x * 374761393 + z * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        return h ^ (h >>> 16);
    }

    // ------------------------------------------------------------------ entities

    private void affectEntities() {
        double lo = Math.max(0.0, prevWave - 2.0);
        double hi = wave + 2.0;
        double lo2 = lo * lo;
        double hi2 = hi * hi;
        double cx = center.getX() + 0.5;
        double cz = center.getZ() + 0.5;
        List<Entity> victims = new ArrayList<>();
        for (Entity e : level.getAllEntities()) {
            double dx = e.getX() - cx;
            double dz = e.getZ() - cz;
            double d2 = dx * dx + dz * dz;
            if (d2 >= lo2 && d2 <= hi2 && e.isAlive()) {
                victims.add(e);
            }
        }
        for (Entity e : victims) {
            if (e instanceof ServerPlayer p) {
                pulsePlayer(p, e.getX() - cx, e.getZ() - cz);
            }
        }
    }

    private void pulsePlayer(ServerPlayer p, double dx, double dz) {
        if (p.isSpectator() || !hit.add(p.getUUID())) {
            return;
        }
        Vec3 dir = new Vec3(dx, 0.0, dz);
        dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize();
        p.setDeltaMovement(dir.x * 1.6, 0.8, dir.z * 1.6);
        p.hurtMarked = true;
    }

    // ------------------------------------------------------------------ effects

    private void onDetonate() {
        double x = center.getX() + 0.5;
        double y = center.getY() + 0.5;
        double z = center.getZ() + 0.5;
        RandomSource rnd = level.random;
        Fx.send(level, new BlastEffectPayload(center, BlastEffectPayload.FLASH, 90, 1));
        Fx.send(level, new BlastEffectPayload(center, BlastEffectPayload.SHAKE, (int) (radius / speed) + 120, 14));
        Fx.loudSound(level, x, y, z, "entity.generic.explode", 80.0F, 0.5F);
        Fx.loudSound(level, x, y, z, "entity.lightning_bolt.thunder", 80.0F, 0.4F);
        Fx.loudSound(level, x, y, z, "entity.warden.sonic_boom", 60.0F, 0.5F);
        Fx.particles(level, ParticleTypes.FLASH, x, y + 2, z, 6, 6.0, 4.0, 6.0, 0.0);
        Fx.particles(level, ParticleTypes.SONIC_BOOM, x, y + 1, z, 1, 0.0, 0.0, 0.0, 0.0);
        for (int i = 0; i < 10; i++) {
            Fx.particles(level, ParticleTypes.EXPLOSION_EMITTER,
                    x + (rnd.nextDouble() - 0.5) * 14.0, y + rnd.nextDouble() * 8.0, z + (rnd.nextDouble() - 0.5) * 14.0,
                    1, 0.0, 0.0, 0.0, 0.0);
        }
        level.setWeatherParameters(0, 24000, true, true);
    }

    private void effects() {
        RandomSource rnd = level.random;
        double cx = center.getX() + 0.5;
        double cy = center.getY() + 0.5;
        double cz = center.getZ() + 0.5;

        // rift plume: rising energy stem + expanding pulse cap
        if (age <= 220) {
            double rise = Math.min(age * 0.8, 75.0);
            double stemR = 2.5 + rise * 0.04;
            for (int i = 0; i < 8; i++) {
                double yy = cy + rnd.nextDouble() * rise;
                double a = rnd.nextDouble() * Math.PI * 2.0;
                double rr = stemR * (0.4 + rnd.nextDouble() * 0.8);
                ParticleOptions p = rnd.nextInt(3) == 0 ? ParticleTypes.FLAME : ParticleTypes.LARGE_SMOKE;
                Fx.particles(level, p, cx + Math.cos(a) * rr, yy, cz + Math.sin(a) * rr, 1, 0.3, 0.3, 0.3, 0.02);
            }
            double capY = cy + rise;
            double capR = Math.min(4.0 + rise * 0.30, 24.0);
            for (int i = 0; i < 10; i++) {
                double a = rnd.nextDouble() * Math.PI * 2.0;
                double rr = capR * (0.6 + rnd.nextDouble() * 0.5);
                double yy = capY + (rnd.nextDouble() - 0.5) * capR * 0.5;
                ParticleOptions p = (i % 4 == 0) ? ParticleTypes.FLAME : (i % 4 == 1) ? ParticleTypes.LAVA : ParticleTypes.LARGE_SMOKE;
                Fx.particles(level, p, cx + Math.cos(a) * rr, yy, cz + Math.sin(a) * rr, 2, 0.4, 0.4, 0.4, 0.03);
            }
            if (age % 6 == 0) {
                Fx.particles(level, ParticleTypes.EXPLOSION_EMITTER,
                        cx + (rnd.nextDouble() - 0.5) * capR, capY, cz + (rnd.nextDouble() - 0.5) * capR, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }

        // the Genesis pulse ring riding on the terrain
        if (cursor < order.length) {
            double r = Math.max(wave, 2.0);
            int pts = Mth.clamp((int) (r * 0.35), 10, 36);
            for (int i = 0; i < pts; i++) {
                double a = (i + rnd.nextDouble()) / pts * Math.PI * 2.0;
                double px = cx + Math.cos(a) * r;
                double pz = cz + Math.sin(a) * r;
                BlockPos bp = BlockPos.containing(px, cy, pz);
                if (!level.hasChunkAt(bp)) {
                    continue;
                }
                double py = level.getHeight(Heightmap.Types.MOTION_BLOCKING, bp.getX(), bp.getZ()) + 0.5;
                Fx.particles(level, ParticleTypes.FLAME, px, py, pz, 4, 1.5, 1.5, 1.5, 0.05);
                Fx.particles(level, ParticleTypes.LARGE_SMOKE, px, py + 1.0, pz, 3, 1.5, 3.0, 1.5, 0.02);
                if (i % 8 == 0 && age % 3 == 0) {
                    Fx.particles(level, ParticleTypes.EXPLOSION_EMITTER, px, py, pz, 1, 0.0, 0.0, 0.0, 0.0);
                }
            }
            if (age % 10 == 0) {
                double a = rnd.nextDouble() * Math.PI * 2.0;
                Fx.loudSound(level, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, "entity.generic.explode", 10.0F, 0.6F + rnd.nextFloat() * 0.3F);
            }
        }

        // lightning striking inside the wave
        if (age < 160 && rnd.nextInt(5) == 0) {
            double a = rnd.nextDouble() * Math.PI * 2.0;
            double rr = rnd.nextDouble() * Math.max(wave, 10.0);
            BlockPos bp = BlockPos.containing(cx + Math.cos(a) * rr, cy, cz + Math.sin(a) * rr);
            if (level.hasChunkAt(bp)) {
                Fx.lightning(level, bp.getX() + 0.5, level.getHeight(Heightmap.Types.MOTION_BLOCKING, bp.getX(), bp.getZ()), bp.getZ() + 0.5);
            }
        }

        // the birth of the gate: a spiral of light climbing into the sky
        if (portalBuilt && age <= (finishAt >= 0 ? finishAt : portalAge + 240)) {
            double a = (age - portalAge) * 0.25;
            for (int k = 0; k < 6; k++) {
                double yy = floorY + 2 + ((age * 2 + k * 17) % 120);
                Fx.particles(level, ParticleTypes.END_ROD, cx + Math.cos(a + k) * 2.2, yy, cz + Math.sin(a + k) * 2.2, 1, 0.05, 0.1, 0.05, 0.01);
            }
            Fx.particles(level, ParticleTypes.REVERSE_PORTAL, cx, floorY + 3, cz, 20, 2.5, 3.0, 0.5, 0.2);
        }
    }
}
