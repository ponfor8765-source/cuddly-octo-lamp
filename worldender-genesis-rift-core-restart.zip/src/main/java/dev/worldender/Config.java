package dev.worldender;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.IntValue BLAST_RADIUS = B
            .comment("Rift pulse radius in blocks. Bigger values affect more terrain and require more server work.")
            .defineInRange("blastRadius", 128, 32, 512);

    public static final ModConfigSpec.IntValue CRATER_DEPTH = B
            .comment("Depth of the terrain basin formed by the Genesis pulse, in blocks.")
            .defineInRange("craterDepth", 40, 8, 120);

    public static final ModConfigSpec.IntValue COUNTDOWN_SECONDS = B
            .comment("Seconds between activating the rift core and the Genesis pulse.")
            .defineInRange("countdownSeconds", 12, 3, 120);

    public static final ModConfigSpec.DoubleValue WAVE_SPEED = B
            .comment("Shockwave speed in blocks per tick.")
            .defineInRange("waveSpeed", 0.6D, 0.1D, 6.0D);

    public static final ModConfigSpec SPEC = B.build();

    private Config() {}
}
