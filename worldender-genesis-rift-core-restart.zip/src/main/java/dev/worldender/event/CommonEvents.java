package dev.worldender.event;

import dev.worldender.blast.BlastManager;
import dev.worldender.entity.AuroraSpider;
import dev.worldender.entity.VoidStalker;
import dev.worldender.net.BlastEffectPayload;
import dev.worldender.registry.ModEntities;
import dev.worldender.world.PortalTravel;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class CommonEvents {
    private CommonEvents() {}

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.VOID_STALKER.get(), VoidStalker.createAttributes().build());
        event.put(ModEntities.LUMEN_BOAR.get(), Pig.createAttributes().build());
        event.put(ModEntities.AURORA_SPIDER.get(), AuroraSpider.createAttributes().build());
    }

    public static void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(ModEntities.VOID_STALKER.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.OR);
        event.register(ModEntities.AURORA_SPIDER.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.OR);
        event.register(ModEntities.LUMEN_BOAR.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::checkAnimalSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.OR);
    }

    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(BlastEffectPayload.TYPE, BlastEffectPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> dev.worldender.client.ClientEffects.handle(payload)));
    }

    public static void onServerTick(ServerTickEvent.Post event) {
        BlastManager.tick();
        PortalTravel.processQueue(event.getServer());
    }

    public static void onServerStopping(ServerStoppingEvent event) {
        BlastManager.clear();
        PortalTravel.clear();
    }
}
