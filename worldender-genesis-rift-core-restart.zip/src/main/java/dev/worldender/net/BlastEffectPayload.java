package dev.worldender.net;

import dev.worldender.WorldEnder;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: camera shake or white flash. */
public record BlastEffectPayload(BlockPos pos, int kind, int duration, int intensity) implements CustomPacketPayload {
    public static final int SHAKE = 0;
    public static final int FLASH = 1;

    public static final CustomPacketPayload.Type<BlastEffectPayload> TYPE =
            new CustomPacketPayload.Type<>(WorldEnder.id("blast_effect"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BlastEffectPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, BlastEffectPayload::pos,
            ByteBufCodecs.VAR_INT, BlastEffectPayload::kind,
            ByteBufCodecs.VAR_INT, BlastEffectPayload::duration,
            ByteBufCodecs.VAR_INT, BlastEffectPayload::intensity,
            BlastEffectPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
