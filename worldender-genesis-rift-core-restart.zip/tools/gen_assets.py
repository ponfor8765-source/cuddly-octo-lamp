"""Generates textures, models, blockstates and lang files for World Ender. Run from anywhere."""
import json, math, os, random
from PIL import Image

ROOT = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', 'src', 'main', 'resources'))
A = os.path.join(ROOT, 'assets', 'worldender')


def wj(rel, obj):
    p = os.path.join(A, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def save(rel, im):
    p = os.path.join(A, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    im.save(p)


def cl(v):
    return max(0, min(255, int(v)))


def jit(c, j, r):
    d = r.randint(-j, j)
    return (cl(c[0] + d), cl(c[1] + d), cl(c[2] + d), 255)


def tex(fn, w=16, h=16):
    im = Image.new('RGBA', (w, h))
    px = im.load()
    for y in range(h):
        for x in range(w):
            px[x, y] = fn(x, y)
    return im


def lerp(a, b, t):
    return tuple(cl(a[i] + (b[i] - a[i]) * t) for i in range(3))


# ------------------------------------------------------------------ block textures
def stone_base(seed):
    r = random.Random(seed)
    im = tex(lambda x, y: jit((40, 36, 62), 9, r))
    px = im.load()
    for _ in range(14):
        px[r.randrange(16), r.randrange(16)] = jit((24, 20, 40), 4, r)
    for _ in range(8):
        px[r.randrange(16), r.randrange(16)] = jit((72, 54, 112), 6, r)
    return im


def ore(seed, c1, c2, n=6):
    im = stone_base(seed)
    px = im.load()
    r = random.Random(seed + 99)
    for _ in range(n):
        cx, cy = r.randrange(2, 14), r.randrange(2, 14)
        shape = [(0, 0), (1, 0), (0, 1), (-1, 0)] if r.random() < 0.6 else [(0, 0), (1, 0), (1, 1), (0, 1)]
        for dx, dy in shape:
            x, y = cx + dx, cy + dy
            if 0 <= x < 16 and 0 <= y < 16:
                px[x, y] = jit(c1 if (dx + dy) % 2 == 0 else c2, 10, r)
        px[cx, cy] = (min(255, c1[0] + 70), min(255, c1[1] + 70), min(255, c1[2] + 70), 255)
    return im


def soil():
    r = random.Random(3)
    im = tex(lambda x, y: jit((78, 50, 90), 10, r))
    px = im.load()
    for _ in range(10):
        px[r.randrange(16), r.randrange(16)] = jit((50, 32, 62), 5, r)
    return im


def grass_top():
    r = random.Random(4)
    im = tex(lambda x, y: jit((34, 190, 150), 14, r))
    px = im.load()
    for _ in range(14):
        px[r.randrange(16), r.randrange(16)] = jit((140, 255, 220), 8, r)
    return im


def grass_side():
    r = random.Random(5)
    im = soil()
    px = im.load()
    tp = grass_top().load()
    for x in range(16):
        for y in range(3 + r.randint(0, 2)):
            px[x, y] = tp[x, y]
    return im


def bricks():
    r = random.Random(11)

    def f(x, y):
        off = 0 if (y // 4) % 2 == 0 else 4
        if y % 4 == 3 or (x + off) % 8 == 7:
            return jit((34, 24, 58), 4, r)
        return jit((86, 62, 134), 10, r)
    im = tex(f)
    px = im.load()
    for _ in range(6):
        x, y = r.randrange(16), r.randrange(16)
        if y % 4 != 3:
            px[x, y] = (190, 120, 255, 255)
    return im


def lumenite_block():
    r = random.Random(21)

    def f(x, y):
        if x in (0, 15) or y in (0, 15):
            return jit((38, 160, 190), 6, r)
        d = (x + y) % 8
        if d == 0:
            return (210, 255, 255, 255)
        if d == 4:
            return (30, 140, 170, 255)
        return jit((60, 215, 230), 14, r)
    return tex(f)


def log_side():
    r = random.Random(31)

    def f(x, y):
        s = [0, -14, 8, -6][x % 4]
        return jit((46 + s, 86 + s, 104 + s), 5, r)
    im = tex(f)
    px = im.load()
    for _ in range(10):
        x, y = r.randrange(16), r.randrange(16)
        for k in range(r.randint(2, 4)):
            if y + k < 16:
                px[x, y + k] = (110, 255, 240, 255)
    return im


def log_top():
    cols = [(150, 255, 245), (70, 170, 190), (46, 100, 120), (80, 190, 205), (46, 100, 120), (60, 140, 160), (46, 86, 104), (46, 86, 104)]
    r = random.Random(32)
    return tex(lambda x, y: jit(cols[min(int(max(abs(x - 7.5), abs(y - 7.5))), 7)], 4, r))


def leaves():
    r = random.Random(41)

    def f(x, y):
        v = r.random()
        if v < 0.12:
            return (190, 255, 255, 255)
        if v < 0.45:
            return jit((60, 200, 205), 10, r)
        return jit((22, 104, 118), 10, r)
    return tex(f)


def bloom():
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    px = im.load()
    for y in range(8, 16):
        px[7, y] = (40, 150, 95, 255)
        px[8, y] = (30, 120, 80, 255)
    for x, y in [(5, 12), (6, 11), (9, 11), (10, 12), (4, 13), (11, 13)]:
        px[x, y] = (45, 170, 105, 255)
    for x, y in [(6, 5), (7, 4), (8, 4), (9, 5), (6, 6), (9, 6), (7, 7), (8, 7)]:
        px[x, y] = (255, 110, 220, 255)
    for x, y in [(7, 5), (8, 5), (7, 6), (8, 6)]:
        px[x, y] = (255, 240, 170, 255)
    for x, y in [(5, 4), (10, 4), (4, 7), (11, 7), (7, 2), (8, 9)]:
        px[x, y] = (160, 255, 255, 200)
    return im


def rift_core_face(glow, seed, kind):
    r = random.Random(seed)
    base = (46, 48, 62) if kind != 'blink' else (80, 70, 78)

    def f(x, y):
        if x in (0, 15) or y in (0, 15):
            return (22, 24, 32, 255)
        for rx, ry in ((2, 2), (13, 2), (2, 13), (13, 13)):
            if (x, y) == (rx, ry):
                return (130, 134, 150, 255)
        d = math.hypot(x - 7.5, y - 7.5)
        if kind != 'bottom':
            if d < 1.9:
                return (min(255, glow[0] + 60), min(255, glow[1] + 60), min(255, glow[2] + 60), 255)
            if 3.4 < d < 5.3:
                return (glow[0], glow[1], glow[2], 255)
            if 5.3 <= d < 6.0:
                return (28, 30, 40, 255)
        if x in (7, 8) and kind == 'top':
            return jit((38, 40, 52), 3, r)
        return jit(base, 6, r)
    return tex(f)


def portal_strip(frames=16):
    strip = Image.new('RGBA', (16, 16 * frames))
    for fr in range(frames):
        ph = fr / frames * 2 * math.pi
        im = Image.new('RGBA', (16, 16))
        px = im.load()
        for y in range(16):
            for x in range(16):
                u, v = x / 16 * 2 * math.pi, y / 16 * 2 * math.pi
                val = (math.sin(u * 2 + ph) + math.sin(v * 3 - ph) + math.sin((u + v) * 2 + ph * 2) + math.sin((u - v) * 3 - ph)) / 4
                t = (val + 1) / 2
                c = lerp((60, 10, 130), (180, 40, 220), t * 2) if t < 0.5 else lerp((180, 40, 220), (120, 240, 255), (t - 0.5) * 2)
                px[x, y] = (c[0], c[1], c[2], 215)
        strip.paste(im, (0, fr * 16))
    return strip


# ------------------------------------------------------------------ item textures
def blank():
    return Image.new('RGBA', (16, 16), (0, 0, 0, 0))


def item_gem():
    im = blank()
    px = im.load()
    for y in range(16):
        for x in range(16):
            d = abs(x - 7.5) / 6.5 + abs(y - 8) / 7.0
            if d <= 1.0:
                c = (70, 225, 235)
                if d > 0.82:
                    c = (22, 130, 160)
                elif x < 8 and y < 8 and d < 0.6:
                    c = (200, 255, 255)
                elif x > 8 and y > 8:
                    c = (40, 170, 200)
                px[x, y] = c + (255,)
    return im


INGOT = [
    "................",
    "................",
    "................",
    "....oooooooo....",
    "...oHHHHHHHHo...",
    "..oHHHHHHHHHDo..",
    "..ooooooooooDo..",
    "..oMMMMMMMMMDo..",
    "..oMMMMMMMMMDo..",
    "..oDDDDDDDDDDo..",
    "...oooooooooo...",
    "................",
    "................",
    "................",
    "................",
    "................",
]
ING_PAL = {'o': (20, 10, 35), 'H': (160, 90, 235), 'M': (70, 36, 112), 'D': (36, 18, 62)}


def item_ingot():
    im = blank()
    px = im.load()
    for y, row in enumerate(INGOT):
        for x, ch in enumerate(row):
            if ch in ING_PAL:
                px[x, y] = ING_PAL[ch] + (255,)
    return im


def item_raw():
    r = random.Random(61)
    im = blank()
    px = im.load()
    rad = [5.2 + r.random() * 1.8 for _ in range(36)]
    for y in range(16):
        for x in range(16):
            a = math.atan2(y - 8, x - 7.5)
            rr = rad[int((a + math.pi) / (2 * math.pi) * 35)]
            if math.hypot(x - 7.5, y - 8) <= rr:
                c = jit((52, 40, 72), 10, r)
                if r.random() < 0.18:
                    c = jit((150, 70, 225), 12, r)
                px[x, y] = c
    return im


def item_shard():
    im = blank()
    px = im.load()
    for i in range(0, 41):
        t = i / 40
        x, y = 3 + 9 * t, 13 - 10 * t
        w = 1.6 * math.sin(math.pi * t) + 0.4
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                if abs(dx) + abs(dy) <= w + 0.5:
                    xx, yy = int(round(x)) + dx, int(round(y)) + dy
                    if 0 <= xx < 16 and 0 <= yy < 16:
                        c = lerp((80, 255, 160), (255, 215, 90), t)
                        px[xx, yy] = c + (255,)
    return im


def line(px, pts, col, width=1):
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        n = max(abs(x1 - x0), abs(y1 - y0), 1) * 2
        for i in range(n + 1):
            x = x0 + (x1 - x0) * i / n
            y = y0 + (y1 - y0) * i / n
            for ox in range(width):
                xx, yy = int(round(x)) + ox, int(round(y))
                if 0 <= xx < 16 and 0 <= yy < 16:
                    px[xx, yy] = col + (255,)


def item_sword():
    im = blank()
    px = im.load()
    line(px, [(1, 14), (5, 10)], (96, 62, 42))
    line(px, [(3, 8), (7, 12)], (60, 36, 84), 1)
    line(px, [(5, 10), (13, 2)], (150, 72, 232), 2)
    line(px, [(6, 9), (14, 1)], (226, 176, 255))
    return im


def item_pickaxe():
    im = blank()
    px = im.load()
    line(px, [(3, 13), (11, 5)], (96, 62, 42))
    line(px, [(3, 6), (4, 4), (6, 3), (8, 2), (10, 3), (12, 5), (13, 7)], (150, 72, 232), 2)
    line(px, [(4, 5), (6, 4), (8, 3), (10, 4), (12, 6)], (226, 176, 255))
    return im


# ------------------------------------------------------------------ entity textures (64x32, vanilla UV layouts)
def entity_base(seed, base, speck, speck_p, j=6):
    r = random.Random(seed)
    im = Image.new('RGBA', (64, 32))
    px = im.load()
    for y in range(32):
        for x in range(64):
            px[x, y] = jit(speck, 10, r) if r.random() < speck_p else jit(base, j, r)
    return im


def tex_void_stalker():
    im = entity_base(71, (20, 12, 34), (110, 50, 190), 0.05)
    px = im.load()
    for x in (9, 10, 13, 14):
        px[x, 12] = (255, 70, 255, 255)
        px[x, 11] = (190, 40, 220, 255)
    return im


def tex_lumen_boar():
    im = entity_base(72, (44, 142, 152), (172, 255, 240), 0.06)
    px = im.load()
    for x in range(8, 16):
        for y in range(8, 16):
            if y > 13:
                px[x, y] = (84, 190, 196, 255)
    px[9, 10] = (10, 40, 50, 255)
    px[14, 10] = (10, 40, 50, 255)
    for x in range(17, 21):
        for y in range(17, 20):
            px[x, y] = (150, 255, 235, 255)
    px[18, 19] = (20, 70, 80, 255)
    px[20, 19] = (20, 70, 80, 255)
    return im


def tex_aurora_spider():
    im = entity_base(73, (14, 18, 42), (60, 255, 200), 0.07)
    px = im.load()
    for x, y in [(41, 14), (42, 14), (45, 14), (46, 14), (43, 13), (44, 13), (42, 16), (45, 16), (43, 15), (44, 15)]:
        px[x, y] = (90, 255, 235, 255)
    return im


# ------------------------------------------------------------------ write everything
def main():
    # block textures
    save('textures/block/genesis_stone.png', stone_base(1))
    save('textures/block/genesis_soil.png', soil())
    save('textures/block/glow_grass_block_top.png', grass_top())
    save('textures/block/glow_grass_block_side.png', grass_side())
    save('textures/block/genesis_bricks.png', bricks())
    save('textures/block/lumenite_block.png', lumenite_block())
    save('textures/block/lumenite_ore.png', ore(2, (90, 240, 245), (40, 170, 190)))
    save('textures/block/voidsteel_ore.png', ore(3, (28, 16, 44), (150, 60, 230), 7))
    save('textures/block/aurorite_ore.png', ore(4, (255, 210, 80), (80, 255, 160)))
    save('textures/block/lumen_log.png', log_side())
    save('textures/block/lumen_log_top.png', log_top())
    save('textures/block/lumen_leaves.png', leaves())
    save('textures/block/glow_bloom.png', bloom())
    cyan, red, white = (90, 200, 255), (255, 60, 40), (255, 235, 210)
    for suffix, glow, kind in (('', cyan, 'idle'), ('_armed', red, 'armed'), ('_blink', white, 'blink')):
        save(f'textures/block/genesis_rift_core_side{suffix}.png', rift_core_face(glow, 81, kind))
        save(f'textures/block/genesis_rift_core_top{suffix}.png', rift_core_face(glow, 82, 'top' if kind != 'blink' else 'blink'))
    save('textures/block/genesis_rift_core_bottom.png', rift_core_face(cyan, 83, 'bottom'))
    save('textures/block/genesis_portal.png', portal_strip())
    wj('textures/block/genesis_portal.png.mcmeta', {"animation": {"frametime": 2, "interpolate": True}})
    # item textures
    save('textures/item/lumenite_gem.png', item_gem())
    save('textures/item/voidsteel_ingot.png', item_ingot())
    save('textures/item/raw_voidsteel.png', item_raw())
    save('textures/item/aurorite_shard.png', item_shard())
    save('textures/item/voidsteel_sword.png', item_sword())
    save('textures/item/voidsteel_pickaxe.png', item_pickaxe())
    # entity textures
    save('textures/entity/void_stalker.png', tex_void_stalker())
    save('textures/entity/lumen_boar.png', tex_lumen_boar())
    save('textures/entity/aurora_spider.png', tex_aurora_spider())

    # ---- blockstates + models
    def bm(name, parent, textures, extra=None):
        d = {"parent": parent, "textures": textures}
        if extra:
            d.update(extra)
        wj(f'models/block/{name}.json', d)

    def simple_state(name):
        wj(f'blockstates/{name}.json', {"variants": {"": {"model": f"worldender:block/{name}"}}})

    for n in ('genesis_bricks', 'genesis_stone', 'genesis_soil', 'lumenite_block', 'lumenite_ore', 'voidsteel_ore', 'aurorite_ore'):
        bm(n, 'minecraft:block/cube_all', {"all": f"worldender:block/{n}"})
        simple_state(n)
    bm('lumen_leaves', 'minecraft:block/cube_all', {"all": "worldender:block/lumen_leaves"}, {"render_type": "minecraft:cutout_mipped"})
    simple_state('lumen_leaves')
    bm('glow_grass_block', 'minecraft:block/cube_bottom_top',
       {"top": "worldender:block/glow_grass_block_top", "side": "worldender:block/glow_grass_block_side", "bottom": "worldender:block/genesis_soil"})
    simple_state('glow_grass_block')
    bm('lumen_log', 'minecraft:block/cube_column', {"end": "worldender:block/lumen_log_top", "side": "worldender:block/lumen_log"})
    wj('blockstates/lumen_log.json', {"variants": {
        "axis=y": {"model": "worldender:block/lumen_log"},
        "axis=z": {"model": "worldender:block/lumen_log", "x": 90},
        "axis=x": {"model": "worldender:block/lumen_log", "x": 90, "y": 90}}})
    bm('glow_bloom', 'minecraft:block/cross', {"cross": "worldender:block/glow_bloom"}, {"render_type": "minecraft:cutout"})
    simple_state('glow_bloom')
    for suffix in ('', '_armed', '_blink'):
        bm(f'genesis_rift_core{suffix}', 'minecraft:block/cube_bottom_top',
           {"top": f"worldender:block/genesis_rift_core_top{suffix}", "side": f"worldender:block/genesis_rift_core_side{suffix}",
            "bottom": "worldender:block/genesis_rift_core_bottom"})
    wj('blockstates/genesis_rift_core.json', {"variants": {
        "armed=false,blink=false": {"model": "worldender:block/genesis_rift_core"},
        "armed=false,blink=true": {"model": "worldender:block/genesis_rift_core"},
        "armed=true,blink=false": {"model": "worldender:block/genesis_rift_core_armed"},
        "armed=true,blink=true": {"model": "worldender:block/genesis_rift_core_blink"}}})
    wj('models/block/genesis_portal.json', {
        "textures": {"particle": "worldender:block/genesis_portal", "portal": "worldender:block/genesis_portal"},
        "elements": [{"from": [0, 0, 6], "to": [16, 16, 10], "faces": {
            "north": {"uv": [0, 0, 16, 16], "texture": "#portal"},
            "south": {"uv": [0, 0, 16, 16], "texture": "#portal"}}}],
        "render_type": "minecraft:translucent"})
    wj('blockstates/genesis_portal.json', {"variants": {
        "axis=x": {"model": "worldender:block/genesis_portal"},
        "axis=z": {"model": "worldender:block/genesis_portal", "y": 90}}})

    # ---- item models
    for n in ('genesis_rift_core', 'genesis_bricks', 'genesis_stone', 'genesis_soil', 'glow_grass_block', 'lumenite_block',
              'lumenite_ore', 'voidsteel_ore', 'aurorite_ore', 'lumen_log', 'lumen_leaves'):
        wj(f'models/item/{n}.json', {"parent": f"worldender:block/{n}"})
    wj('models/item/glow_bloom.json', {"parent": "minecraft:item/generated", "textures": {"layer0": "worldender:block/glow_bloom"}})
    for n in ('lumenite_gem', 'raw_voidsteel', 'voidsteel_ingot', 'aurorite_shard'):
        wj(f'models/item/{n}.json', {"parent": "minecraft:item/generated", "textures": {"layer0": f"worldender:item/{n}"}})
    for n in ('voidsteel_sword', 'voidsteel_pickaxe'):
        wj(f'models/item/{n}.json', {"parent": "minecraft:item/handheld", "textures": {"layer0": f"worldender:item/{n}"}})
    for n in ('void_stalker', 'lumen_boar', 'aurora_spider'):
        wj(f'models/item/{n}_spawn_egg.json', {"parent": "minecraft:item/template_spawn_egg"})

    # ---- language files
    en = {
        "itemGroup.worldender": "World Ender",
        "block.worldender.genesis_rift_core": "Genesis Rift Core",
        "block.worldender.genesis_portal": "Genesis Portal",
        "block.worldender.genesis_bricks": "Genesis Bricks",
        "block.worldender.genesis_stone": "Genesis Stone",
        "block.worldender.genesis_soil": "Genesis Soil",
        "block.worldender.glow_grass_block": "Glow Grass Block",
        "block.worldender.lumenite_block": "Block of Lumenite",
        "block.worldender.lumenite_ore": "Lumenite Ore",
        "block.worldender.voidsteel_ore": "Voidsteel Ore",
        "block.worldender.aurorite_ore": "Aurorite Ore",
        "block.worldender.lumen_log": "Lumen Log",
        "block.worldender.lumen_leaves": "Lumen Leaves",
        "block.worldender.glow_bloom": "Glow Bloom",
        "item.worldender.lumenite_gem": "Lumenite Gem",
        "item.worldender.raw_voidsteel": "Raw Voidsteel",
        "item.worldender.voidsteel_ingot": "Voidsteel Ingot",
        "item.worldender.aurorite_shard": "Aurorite Shard",
        "item.worldender.voidsteel_sword": "Voidsteel Sword",
        "item.worldender.voidsteel_pickaxe": "Voidsteel Pickaxe",
        "item.worldender.void_stalker_spawn_egg": "Void Stalker Spawn Egg",
        "item.worldender.lumen_boar_spawn_egg": "Lumen Boar Spawn Egg",
        "item.worldender.aurora_spider_spawn_egg": "Aurora Spider Spawn Egg",
        "entity.worldender.void_stalker": "Void Stalker",
        "entity.worldender.lumen_boar": "Lumen Boar",
        "entity.worldender.aurora_spider": "Aurora Spider",
        "message.worldender.armed": "GENESIS BOMB ARMED! RUN!",
        "message.worldender.countdown": "Detonation in %s...",
        "message.worldender.rejected": "The Genesis dimension cannot be destroyed.",
        "message.worldender.no_sky": "The bomb only works in dimensions with an open sky.",
        "message.worldender.no_dimension": "The Genesis dimension is not available.",
        "message.worldender.gate_lost": "The gate on the other side is gone. You were returned to the world spawn.",
    }
    ru = dict(en)
    ru.update({
        "itemGroup.worldender": "Конец Света",
        "block.worldender.genesis_rift_core": "Ядро Разлома Генезиса",
        "block.worldender.genesis_portal": "Портал Генезиса",
        "block.worldender.genesis_bricks": "Кирпичи Генезиса",
        "block.worldender.genesis_stone": "Камень Генезиса",
        "block.worldender.genesis_soil": "Почва Генезиса",
        "block.worldender.glow_grass_block": "Светящийся травяной блок",
        "block.worldender.lumenite_block": "Блок люменита",
        "block.worldender.lumenite_ore": "Люменитовая руда",
        "block.worldender.voidsteel_ore": "Руда пустотной стали",
        "block.worldender.aurorite_ore": "Ауроритовая руда",
        "block.worldender.lumen_log": "Люмен-бревно",
        "block.worldender.lumen_leaves": "Люмен-листва",
        "block.worldender.glow_bloom": "Светоцвет",
        "item.worldender.lumenite_gem": "Люменит",
        "item.worldender.raw_voidsteel": "Сырая пустотная сталь",
        "item.worldender.voidsteel_ingot": "Слиток пустотной стали",
        "item.worldender.aurorite_shard": "Осколок ауроритa",
        "item.worldender.voidsteel_sword": "Меч из пустотной стали",
        "item.worldender.voidsteel_pickaxe": "Кирка из пустотной стали",
        "item.worldender.void_stalker_spawn_egg": "Яйцо призвания Преследователя Пустоты",
        "item.worldender.lumen_boar_spawn_egg": "Яйцо призвания Люмен-кабана",
        "item.worldender.aurora_spider_spawn_egg": "Яйцо призвания Паука-авроры",
        "entity.worldender.void_stalker": "Преследователь Пустоты",
        "entity.worldender.lumen_boar": "Люмен-кабан",
        "entity.worldender.aurora_spider": "Паук-аврора",
        "message.worldender.armed": "БОМБА ГЕНЕЗИСА АКТИВИРОВАНА! БЕГИ!",
        "message.worldender.countdown": "Взрыв через %s...",
        "message.worldender.rejected": "Измерение Генезиса нельзя уничтожить.",
        "message.worldender.no_sky": "Ядро разлома работает только в измерениях с открытым небом.",
        "message.worldender.no_dimension": "Измерение Генезиса недоступно.",
        "message.worldender.gate_lost": "Врат с той стороны больше нет. Вы возвращены на точку мира.",
    })
    ru["item.worldender.aurorite_shard"] = "Осколок ауроритa".replace('a', 'а')
    wj('lang/en_us.json', en)
    wj('lang/ru_ru.json', ru)
    print("assets generated")


main()
