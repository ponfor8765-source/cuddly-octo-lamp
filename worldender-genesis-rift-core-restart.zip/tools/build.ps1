$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot\..

function Get-JavaMajor([string]$JavaExe) {
    if (-not (Test-Path -LiteralPath $JavaExe)) { return $null }
    $output = & $JavaExe -version 2>&1 | Out-String
    if ($output -match 'version "([0-9]+)') { return [int]$Matches[1] }
    return $null
}

function Find-Java21 {
    $candidates = New-Object System.Collections.Generic.List[string]
    if ($env:JAVA_HOME) { $candidates.Add((Join-Path $env:JAVA_HOME 'bin\java.exe')) }
    $pathJava = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($pathJava) { $candidates.Add($pathJava.Source) }
    $roots = @(
        'C:\Program Files\Eclipse Adoptium',
        'C:\Program Files\Microsoft',
        'C:\Program Files\Java',
        'C:\Program Files\Amazon Corretto',
        'C:\Program Files\BellSoft'
    )
    foreach ($root in $roots) {
        if (Test-Path $root) {
            Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
                ForEach-Object {
                    $p = Join-Path $_.FullName 'bin\java.exe'
                    if (Test-Path $p) { $candidates.Add($p) }
                }
        }
    }
    foreach ($java in ($candidates | Select-Object -Unique)) {
        $major = Get-JavaMajor $java
        if ($major -eq 21) { return $java }
    }
    foreach ($java in ($candidates | Select-Object -Unique)) {
        $major = Get-JavaMajor $java
        if ($major -ge 17) { return $java }
    }
    return $null
}

Write-Host '[1/4] Locating Java 21...'
$javaExe = Find-Java21
if (-not $javaExe) {
    Write-Host ''
    Write-Host '[ERROR] Java 21 was not found.' -ForegroundColor Red
    Write-Host 'Install a 64-bit JDK 21 and run build.bat again.'
    exit 2
}

$javaHome = Split-Path -Parent (Split-Path -Parent $javaExe)
$env:JAVA_HOME = $javaHome
$env:PATH = (Join-Path $javaHome 'bin') + ';' + $env:PATH
$javaVersion = (& $javaExe -version 2>&1 | Select-Object -First 1)
Write-Host "[OK] $javaVersion"
Write-Host "[OK] JAVA_HOME=$javaHome"

Write-Host '[2/4] Preparing Gradle 8.10.2...'
$gradleVersion = '8.10.2'
$localRoot = Join-Path (Get-Location) '.gradle-local'
$gradleHome = Join-Path $localRoot "gradle-$gradleVersion"
$gradleBat = Join-Path $gradleHome 'bin\gradle.bat'

if (-not (Test-Path $gradleBat)) {
    New-Item -ItemType Directory -Force -Path $localRoot | Out-Null
    $zip = Join-Path $localRoot "gradle-$gradleVersion-bin.zip"
    $urls = @(
        "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip",
        "https://downloads.gradle.org/distributions/gradle-$gradleVersion-bin.zip"
    )
    $downloaded = $false
    foreach ($url in $urls) {
        try {
            Write-Host "[INFO] Downloading $url"
            Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip
            if ((Get-Item $zip).Length -gt 10000000) { $downloaded = $true; break }
        } catch {
            Write-Host "[WARN] Download failed: $($_.Exception.Message)"
        }
    }
    if (-not $downloaded) {
        Write-Host '[ERROR] Gradle could not be downloaded. Check Internet access.' -ForegroundColor Red
        exit 3
    }
    Expand-Archive -LiteralPath $zip -DestinationPath $localRoot -Force
}

if (-not (Test-Path $gradleBat)) {
    Write-Host '[ERROR] Gradle installation is incomplete.' -ForegroundColor Red
    exit 4
}
Write-Host "[OK] Gradle $gradleVersion"

Write-Host '[3/4] Running clean build with Java 21...'
Write-Host '[INFO] The first NeoForge/Minecraft dependency setup can take a while.'
Write-Host ''

$javaHomeArg = "-Dorg.gradle.java.home=$javaHome"
& $gradleBat '--no-daemon' '--stacktrace' $javaHomeArg 'clean' 'build'
$result = $LASTEXITCODE
if ($result -ne 0) {
    Write-Host ''
    Write-Host "[ERROR] Gradle build failed with exit code $result" -ForegroundColor Red
    exit $result
}

Write-Host ''
Write-Host '[4/4] Verifying final artifacts...'
$artifacts = Get-ChildItem -LiteralPath (Join-Path (Get-Location) 'build\libs') -Filter '*.jar' -File -ErrorAction SilentlyContinue
if (-not $artifacts) {
    Write-Host '[ERROR] Gradle reported success, but no JAR was produced.' -ForegroundColor Red
    exit 5
}
foreach ($artifact in $artifacts) {
    $sha = (Get-FileHash -Algorithm SHA256 -LiteralPath $artifact.FullName).Hash
    Write-Host "[ARTIFACT] $($artifact.Name)  SHA256=$sha"
}
$runtimeJar = $artifacts | Where-Object { $_.Name -notmatch '-sources\.jar$' } | Select-Object -First 1
if (-not $runtimeJar) {
    Write-Host '[ERROR] Only sources JARs were produced.' -ForegroundColor Red
    exit 6
}
Write-Host ''
Write-Host "[OK] INSTALLABLE JAR: $($runtimeJar.FullName)" -ForegroundColor Green
exit 0
