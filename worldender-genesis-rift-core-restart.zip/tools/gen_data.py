"""Generates data-pack JSON (loot, recipes, tags, worldgen) and NBT structure templates for World Ender."""
import gzip, json, math, os, struct

ROOT = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', 'src', 'main', 'resources', 'data'))
W = 'worldender'


def wj(ns, rel, obj):
    p = os.path.join(ROOT, ns, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=2)


def uni(a, b):
    return {"type": "minecraft:uniform", "min": float(a), "max": float(b)}


# ================================================================== loot tables
def block_loot(name, item=None, count=None):
    entry = {"type": "minecraft:item", "name": item or f"{W}:{name}"}
    if count:
        entry["functions"] = [{"function": "minecraft:set_count", "count": uni(*count)}]
    return {"type": "minecraft:block", "random_sequence": f"{W}:blocks/{name}",
            "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "conditions": [{"condition": "minecraft:survives_explosion"}], "entries": [entry]}]}


SILK = {"condition": "minecraft:match_tool", "predicate": {"predicates": {"minecraft:enchantments": [
    {"enchantments": "minecraft:silk_touch", "levels": {"min": 1}}]}}}


def ore_loot(name, drop, count=None):
    funcs = []
    if count:
        funcs.append({"function": "minecraft:set_count", "count": uni(*count)})
    funcs += [{"function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops"},
              {"function": "minecraft:explosion_decay"}]
    return {"type": "minecraft:block", "random_sequence": f"{W}:blocks/{name}", "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [
        {"type": "minecraft:alternatives", "children": [
            {"type": "minecraft:item", "conditions": [SILK], "name": f"{W}:{name}"},
            {"type": "minecraft:item", "functions": funcs, "name": f"{W}:{drop}"}]}]}]}


def silk_or(name, otherwise):
    other = {"type": "minecraft:item", "name": otherwise} if otherwise else None
    children = [{"type": "minecraft:item", "conditions": [SILK], "name": f"{W}:{name}"}]
    if other:
        children.append(other)
    return {"type": "minecraft:block", "random_sequence": f"{W}:blocks/{name}",
            "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{"type": "minecraft:alternatives", "children": children}]}]}


def leaves_loot():
    cond = {"condition": "minecraft:any_of", "terms": [
        {"condition": "minecraft:match_tool", "predicate": {"items": "minecraft:shears"}}, SILK]}
    return {"type": "minecraft:block", "random_sequence": f"{W}:blocks/lumen_leaves",
            "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "conditions": [cond],
                       "entries": [{"type": "minecraft:item", "name": f"{W}:lumen_leaves"}]}]}


def mob_loot(entries):
    pools = []
    for name, lo, hi in entries:
        pools.append({"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{"type": "minecraft:item", "name": name, "functions": [
            {"function": "minecraft:set_count", "count": uni(lo, hi), "add": False},
            {"function": "minecraft:looting_enchant", "count": uni(0, 1)}]}]})
    return {"type": "minecraft:entity", "pools": pools}


def chest_loot(rolls, items):
    entries = []
    for name, weight, lo, hi in items:
        e = {"type": "minecraft:item", "name": name, "weight": weight}
        if hi > 1:
            e["functions"] = [{"function": "minecraft:set_count", "count": uni(lo, hi)}]
        entries.append(e)
    return {"type": "minecraft:chest", "pools": [{"rolls": uni(*rolls), "bonus_rolls": 0.0, "entries": entries}]}


def write_loot():
    for n in ('genesis_rift_core', 'genesis_bricks', 'genesis_stone', 'genesis_soil', 'lumenite_block', 'lumen_log', 'glow_bloom'):
        wj(W, f'loot_table/blocks/{n}.json', block_loot(n))
    wj(W, 'loot_table/blocks/glow_grass_block.json', silk_or('glow_grass_block', f'{W}:genesis_soil'))
    wj(W, 'loot_table/blocks/lumenite_ore.json', ore_loot('lumenite_ore', 'lumenite_gem'))
    wj(W, 'loot_table/blocks/voidsteel_ore.json', ore_loot('voidsteel_ore', 'raw_voidsteel'))
    wj(W, 'loot_table/blocks/aurorite_ore.json', ore_loot('aurorite_ore', 'aurorite_shard', (1, 3)))
    wj(W, 'loot_table/blocks/lumen_leaves.json', leaves_loot())
    wj(W, 'loot_table/entities/void_stalker.json', mob_loot([(f'{W}:raw_voidsteel', 0, 2), ('minecraft:ender_pearl', 0, 1)]))
    wj(W, 'loot_table/entities/aurora_spider.json', mob_loot([('minecraft:string', 0, 2), (f'{W}:aurorite_shard', 0, 1)]))
    wj(W, 'loot_table/entities/lumen_boar.json', mob_loot([('minecraft:porkchop', 1, 3), (f'{W}:lumenite_gem', 0, 1)]))
    wj(W, 'loot_table/chests/obelisk.json', chest_loot((3, 6), [
        (f'{W}:lumenite_gem', 20, 2, 6), (f'{W}:voidsteel_ingot', 10, 1, 3), (f'{W}:aurorite_shard', 8, 1, 3),
        ('minecraft:diamond', 4, 1, 2), ('minecraft:golden_apple', 3, 1, 1), ('minecraft:ender_pearl', 6, 1, 3)]))
    wj(W, 'loot_table/chests/ring.json', chest_loot((3, 5), [
        (f'{W}:aurorite_shard', 20, 2, 5), (f'{W}:lumenite_block', 6, 1, 2), (f'{W}:voidsteel_ingot', 10, 1, 2),
        ('minecraft:experience_bottle', 8, 2, 6), ('minecraft:emerald', 8, 2, 5)]))
    wj(W, 'loot_table/chests/tower.json', chest_loot((4, 7), [
        (f'{W}:voidsteel_ingot', 14, 2, 5), (f'{W}:voidsteel_sword', 3, 1, 1), (f'{W}:voidsteel_pickaxe', 3, 1, 1),
        (f'{W}:lumenite_gem', 16, 3, 8), ('minecraft:netherite_scrap', 3, 1, 2), ('minecraft:ender_pearl', 8, 2, 4),
        (f'{W}:genesis_rift_core', 1, 1, 1), ('minecraft:diamond', 6, 1, 3)]))


# ================================================================== recipes
def item(i):
    return {"item": i}


def shaped(pattern, key, result, count=1):
    return {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern,
            "key": {k: item(v) for k, v in key.items()}, "result": {"count": count, "id": result}}


def cooking(kind, ingredients, result, xp, time):
    return {"type": f"minecraft:{kind}", "category": "misc", "cookingtime": time, "experience": xp,
            "ingredient": [item(i) for i in ingredients], "result": {"id": result}}


def write_recipes():
    wj(W, 'recipe/genesis_rift_core.json', shaped(["AEA", "NSN", "AEA"],
       {"A": "minecraft:amethyst_shard", "E": "minecraft:echo_shard", "N": "minecraft:netherite_ingot", "S": "minecraft:nether_star"}, f'{W}:genesis_rift_core'))
    wj(W, 'recipe/lumenite_block.json', shaped(["GGG", "GGG", "GGG"], {"G": f"{W}:lumenite_gem"}, f'{W}:lumenite_block'))
    wj(W, 'recipe/lumenite_gem_from_block.json', {"type": "minecraft:crafting_shapeless", "category": "misc",
       "ingredients": [item(f'{W}:lumenite_block')], "result": {"count": 9, "id": f'{W}:lumenite_gem'}})
    wj(W, 'recipe/genesis_bricks.json', shaped(["SS", "SS"], {"S": f"{W}:genesis_stone"}, f'{W}:genesis_bricks', 4))
    wj(W, 'recipe/voidsteel_ingot_smelting.json', cooking('smelting', [f'{W}:raw_voidsteel', f'{W}:voidsteel_ore'], f'{W}:voidsteel_ingot', 1.0, 200))
    wj(W, 'recipe/voidsteel_ingot_blasting.json', cooking('blasting', [f'{W}:raw_voidsteel', f'{W}:voidsteel_ore'], f'{W}:voidsteel_ingot', 1.0, 100))
    wj(W, 'recipe/voidsteel_sword.json', shaped([" I ", " I ", " S "], {"I": f"{W}:voidsteel_ingot", "S": "minecraft:stick"}, f'{W}:voidsteel_sword'))
    wj(W, 'recipe/voidsteel_pickaxe.json', shaped(["III", " S ", " S "], {"I": f"{W}:voidsteel_ingot", "S": "minecraft:stick"}, f'{W}:voidsteel_pickaxe'))


# ================================================================== tags
def tag(ns, rel, values):
    wj(ns, f'tags/{rel}.json', {"replace": False, "values": values})


def write_tags():
    b = lambda *n: [f'{W}:{x}' for x in n]
    tag('minecraft', 'block/mineable/pickaxe', b('genesis_rift_core', 'genesis_bricks', 'genesis_stone', 'lumenite_block', 'lumenite_ore', 'voidsteel_ore', 'aurorite_ore'))
    tag('minecraft', 'block/mineable/axe', b('lumen_log'))
    tag('minecraft', 'block/mineable/hoe', b('lumen_leaves'))
    tag('minecraft', 'block/mineable/shovel', b('genesis_soil', 'glow_grass_block'))
    tag('minecraft', 'block/needs_iron_tool', b('lumenite_ore', 'lumenite_block', 'genesis_rift_core'))
    tag('minecraft', 'block/needs_diamond_tool', b('voidsteel_ore', 'aurorite_ore', 'genesis_bricks'))
    tag('minecraft', 'block/logs', b('lumen_log'))
    tag('minecraft', 'block/logs_that_burn', b('lumen_log'))
    tag('minecraft', 'block/leaves', b('lumen_leaves'))
    tag('minecraft', 'block/dirt', b('glow_grass_block', 'genesis_soil'))
    tag('minecraft', 'block/animals_spawnable_on', b('glow_grass_block'))
    tag('minecraft', 'block/overworld_carver_replaceables', b('genesis_stone', 'genesis_soil', 'glow_grass_block'))


# ================================================================== worldgen
def st(name, props=None):
    d = {"Name": name}
    if props:
        d["Properties"] = props
    return d


def provider(name, props=None):
    return {"type": "minecraft:simple_state_provider", "state": st(name, props)}


def write_dimension():
    wj(W, 'dimension_type/genesis.json', {
        "ultrawarm": False, "natural": True, "coordinate_scale": 1.0, "has_skylight": True, "has_ceiling": False,
        "ambient_light": 0.2, "fixed_time": 18000,
        "monster_spawn_light_level": {"type": "minecraft:uniform", "min_inclusive": 0, "max_inclusive": 7},
        "monster_spawn_block_light_limit": 0, "piglin_safe": False, "bed_works": False, "respawn_anchor_works": False,
        "has_raids": False, "logical_height": 384, "min_y": -64, "height": 384,
        "infiniburn": "#minecraft:infiniburn_overworld", "effects": "minecraft:overworld"})

    def noise2d(name, scale):
        return {"type": "minecraft:flat_cache", "argument": {"type": "minecraft:noise", "noise": name, "xz_scale": scale, "y_scale": 0.0}}
    terrain = {"type": "minecraft:add",
               "argument1": {"type": "minecraft:add",
                             "argument1": {"type": "minecraft:y_clamped_gradient", "from_y": -64, "to_y": 192, "from_value": 3.2, "to_value": -3.2},
                             "argument2": {"type": "minecraft:old_blended_noise", "xz_scale": 0.25, "y_scale": 0.125,
                                           "xz_factor": 80.0, "y_factor": 160.0, "smear_scale_multiplier": 8.0}},
               "argument2": {"type": "minecraft:mul", "argument1": 0.9, "argument2": noise2d("minecraft:continentalness", 1.5)}}

    def cond(if_true, then_run):
        return {"type": "minecraft:condition", "if_true": if_true, "then_run": then_run}

    def seq(*items):
        return {"type": "minecraft:sequence", "sequence": list(items)}

    def blk(name):
        return {"type": "minecraft:block", "result_state": st(name)}
    on_floor = {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": False, "secondary_depth_range": 0}
    under_floor = {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": True, "secondary_depth_range": 0}
    dry = {"type": "minecraft:water", "offset": -1, "surface_depth_multiplier": 0, "add_stone_depth": False}

    def biome_is(n):
        return {"type": "minecraft:biome", "biome_is": [f"{W}:{n}"]}
    surface = seq(
        cond({"type": "minecraft:vertical_gradient", "random_name": "minecraft:bedrock_floor",
              "true_at_and_below": {"above_bottom": 0}, "false_at_and_above": {"above_bottom": 5}}, blk("minecraft:bedrock")),
        cond(biome_is("crystal_wastes"), seq(cond(on_floor, blk("minecraft:calcite")), cond(under_floor, blk("minecraft:tuff")))),
        cond(biome_is("void_marsh"), seq(cond(on_floor, seq(cond(dry, blk("minecraft:moss_block")), blk("minecraft:mud"))),
                                         cond(under_floor, blk("minecraft:mud")))),
        cond(on_floor, seq(cond(dry, blk(f"{W}:glow_grass_block")), blk("minecraft:gravel"))),
        cond(under_floor, blk(f"{W}:genesis_soil")))
    wj(W, 'worldgen/noise_settings/genesis.json', {
        "sea_level": 48, "disable_mob_generation": False, "aquifers_enabled": False, "ore_veins_enabled": False,
        "legacy_random_source": False,
        "default_block": st(f"{W}:genesis_stone"),
        "default_fluid": st("minecraft:water", {"level": "0"}),
        "noise": {"min_y": -64, "height": 384, "size_horizontal": 1, "size_vertical": 2},
        "noise_router": {
            "barrier": 0.0, "fluid_level_floodedness": 0.0, "fluid_level_spread": 0.0, "lava": 0.0,
            "temperature": noise2d("minecraft:temperature", 1.5), "vegetation": noise2d("minecraft:vegetation", 1.5),
            "continents": 0.0, "erosion": 0.0, "depth": 0.0, "ridges": 0.0,
            "initial_density_without_jaggedness": terrain,
            "final_density": {"type": "minecraft:interpolated", "argument": terrain},
            "vein_toggle": 0.0, "vein_ridged": 0.0, "vein_gap": 0.0},
        "spawn_target": [], "surface_rule": surface})

    def entry(biome, temp, hum):
        return {"biome": f"{W}:{biome}", "parameters": {
            "temperature": temp, "humidity": hum, "continentalness": [-2.0, 2.0], "erosion": [-2.0, 2.0],
            "weirdness": [-2.0, 2.0], "depth": [-2.0, 2.0], "offset": 0.0}}
    wj(W, 'dimension/genesis.json', {"type": f"{W}:genesis", "generator": {
        "type": "minecraft:noise", "settings": f"{W}:genesis",
        "biome_source": {"type": "minecraft:multi_noise", "biomes": [
            entry("glow_plains", [-0.25, 0.35], [-1.0, 0.0]),
            entry("lumen_forest", [-0.25, 0.35], [0.0, 1.0]),
            entry("crystal_wastes", [0.35, 1.0], [-1.0, 1.0]),
            entry("void_marsh", [-1.0, -0.25], [-1.0, 1.0])]}}})


def spawn(t, w, lo, hi):
    return {"type": t, "weight": w, "minCount": lo, "maxCount": hi}


def write_biomes():
    # global feature order per step (consistent across biomes, avoids feature-cycle errors)
    def biome(name, temp, down, fog, sky, water, water_fog, grass, foliage, particle, p_prob, vegetal, deco, monsters, creatures):
        feats = [[] for _ in range(11)]
        feats[6] = [f"{W}:ore_lumenite", f"{W}:ore_voidsteel", f"{W}:ore_aurorite"]
        feats[7] = deco
        feats[9] = vegetal
        wj(W, f'worldgen/biome/{name}.json', {
            "has_precipitation": False, "temperature": temp, "downfall": down,
            "effects": {"fog_color": fog, "sky_color": sky, "water_color": water, "water_fog_color": water_fog,
                        "grass_color": grass, "foliage_color": foliage,
                        "particle": {"probability": p_prob, "options": {"type": particle}},
                        "mood_sound": {"sound": "minecraft:ambient.cave", "tick_delay": 6000, "block_search_extent": 8, "offset": 2.0}},
            "spawners": {"monster": monsters, "creature": creatures},
            "spawn_costs": {},
            "carvers": {"air": ["minecraft:cave", "minecraft:cave_extra_underground", "minecraft:canyon"]},  # 1.21.1: map keyed by step
            "features": feats})
    stalker, spider, boar = f"{W}:void_stalker", f"{W}:aurora_spider", f"{W}:lumen_boar"
    biome("glow_plains", 0.8, 0.4, 0x3B2A8F, 0x4A3AA8, 0x2FD6C4, 0x0E5A63, 0x35E0A8, 0x3BE0D6, "minecraft:end_rod", 0.004,
          [f"{W}:lumen_tree_sparse", f"{W}:glow_bloom_patch"], [],
          [spawn(spider, 25, 1, 3), spawn(stalker, 8, 1, 1), spawn("minecraft:enderman", 5, 1, 2)], [spawn(boar, 12, 2, 4)])
    biome("lumen_forest", 0.7, 0.8, 0x14304A, 0x1E4A8A, 0x22B5D0, 0x0B4A5A, 0x1FC77A, 0x28D9E8, "minecraft:glow", 0.01,
          [f"{W}:lumen_tree_dense", f"{W}:lumen_tree_big", f"{W}:glow_bloom_patch"], [],
          [spawn(spider, 30, 1, 3), spawn(stalker, 12, 1, 2), spawn("minecraft:enderman", 5, 1, 2)], [spawn(boar, 15, 2, 5)])
    biome("crystal_wastes", 1.2, 0.0, 0x5A2A7A, 0x7A3AB8, 0xB06AF0, 0x4A2A70, 0xA8B0FF, 0xC0A8FF, "minecraft:white_ash", 0.02,
          [f"{W}:lumenite_spire"], ["minecraft:amethyst_geode"],
          [spawn(stalker, 30, 1, 3), spawn(spider, 20, 1, 2)], [])
    biome("void_marsh", 0.2, 0.9, 0x0A1A24, 0x102A3A, 0x1A6A6A, 0x06282C, 0x2A8A6A, 0x2A9A8A, "minecraft:warped_spore", 0.03,
          [f"{W}:lumen_tree_sparse", f"{W}:glow_bloom_patch"], [],
          [spawn(stalker, 35, 1, 3), spawn(spider, 20, 1, 2)], [spawn(boar, 5, 1, 2)])


def write_features():
    def ore(name, state, size, count, lo, hi):
        wj(W, f'worldgen/configured_feature/{name}.json', {"type": "minecraft:ore", "config": {
            "discard_chance_on_air_exposure": 0.0, "size": size,
            "targets": [{"state": st(state), "target": {"predicate_type": "minecraft:block_match", "block": f"{W}:genesis_stone"}}]}})
        wj(W, f'worldgen/placed_feature/{name}.json', {"feature": f"{W}:{name}", "placement": [
            {"type": "minecraft:count", "count": count}, {"type": "minecraft:in_square"},
            {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": lo}, "max_inclusive": {"absolute": hi}}},
            {"type": "minecraft:biome"}]})
    ore("ore_lumenite", f"{W}:lumenite_ore", 9, 16, -48, 90)
    ore("ore_voidsteel", f"{W}:voidsteel_ore", 6, 9, -64, 24)
    ore("ore_aurorite", f"{W}:aurorite_ore", 4, 4, -64, 0)

    leaves = provider(f"{W}:lumen_leaves", {"distance": "7", "persistent": "false", "waterlogged": "false"})
    log = provider(f"{W}:lumen_log", {"axis": "y"})
    dirt = provider(f"{W}:genesis_soil")

    def tree(name, foliage, trunk, size):
        wj(W, f'worldgen/configured_feature/{name}.json', {"type": "minecraft:tree", "config": {
            "decorators": [], "dirt_provider": dirt, "foliage_placer": foliage, "foliage_provider": leaves,
            "force_dirt": False, "ignore_vines": True, "minimum_size": size, "trunk_placer": trunk, "trunk_provider": log}})

    def placed_tree(name, count):
        wj(W, f'worldgen/placed_feature/{name}.json', {"feature": f"{W}:{name}", "placement": [
            {"type": "minecraft:count", "count": count}, {"type": "minecraft:in_square"},
            {"type": "minecraft:surface_water_depth_filter", "max_water_depth": 0},
            {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR"}, {"type": "minecraft:biome"}]})
    small = {"type": "minecraft:two_layers_feature_size", "limit": 1, "lower_size": 0, "upper_size": 1}
    tree("lumen_tree", {"type": "minecraft:blob_foliage_placer", "height": 3, "offset": 0, "radius": 2},
         {"type": "minecraft:straight_trunk_placer", "base_height": 5, "height_rand_a": 2, "height_rand_b": 1}, small)
    tree("lumen_tree_big_cfg", {"type": "minecraft:fancy_foliage_placer", "height": 4, "offset": 4, "radius": 3},
         {"type": "minecraft:fancy_trunk_placer", "base_height": 10, "height_rand_a": 6, "height_rand_b": 3},
         {"type": "minecraft:two_layers_feature_size", "limit": 0, "lower_size": 0, "upper_size": 0, "min_clipped_height": 4})
    wj(W, 'worldgen/placed_feature/lumen_tree_dense.json', {"feature": f"{W}:lumen_tree", "placement": [
        {"type": "minecraft:count", "count": 9}, {"type": "minecraft:in_square"},
        {"type": "minecraft:surface_water_depth_filter", "max_water_depth": 0},
        {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR"}, {"type": "minecraft:biome"}]})
    wj(W, 'worldgen/placed_feature/lumen_tree_sparse.json', {"feature": f"{W}:lumen_tree", "placement": [
        {"type": "minecraft:count", "count": {"type": "minecraft:uniform", "min_inclusive": 0, "max_inclusive": 2}}, {"type": "minecraft:in_square"},
        {"type": "minecraft:surface_water_depth_filter", "max_water_depth": 0},
        {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR"}, {"type": "minecraft:biome"}]})
    wj(W, 'worldgen/placed_feature/lumen_tree_big.json', {"feature": f"{W}:lumen_tree_big_cfg", "placement": [
        {"type": "minecraft:count", "count": 2}, {"type": "minecraft:in_square"},
        {"type": "minecraft:surface_water_depth_filter", "max_water_depth": 0},
        {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR"}, {"type": "minecraft:biome"}]})

    wj(W, 'worldgen/configured_feature/glow_bloom_patch.json', {"type": "minecraft:random_patch", "config": {
        "tries": 32, "xz_spread": 7, "y_spread": 3, "feature": {
            "feature": {"type": "minecraft:simple_block", "config": {"to_place": provider(f"{W}:glow_bloom")}},
            "placement": [{"type": "minecraft:block_predicate_filter", "predicate": {"type": "minecraft:matching_blocks", "blocks": "minecraft:air"}}]}}})
    wj(W, 'worldgen/placed_feature/glow_bloom_patch.json', {"feature": f"{W}:glow_bloom_patch", "placement": [
        {"type": "minecraft:count", "count": 2}, {"type": "minecraft:in_square"},
        {"type": "minecraft:heightmap", "heightmap": "WORLD_SURFACE_WG"}, {"type": "minecraft:biome"}]})
    wj(W, 'worldgen/configured_feature/lumenite_spire.json', {"type": "minecraft:block_column", "config": {
        "allowed_placement": {"type": "minecraft:matching_blocks", "blocks": "minecraft:air"}, "direction": "up",
        "layers": [{"height": {"type": "minecraft:uniform", "min_inclusive": 3, "max_inclusive": 9}, "provider": provider(f"{W}:lumenite_block")}],
        "prioritize_tip": False}})
    wj(W, 'worldgen/placed_feature/lumenite_spire.json', {"feature": f"{W}:lumenite_spire", "placement": [
        {"type": "minecraft:count", "count": {"type": "minecraft:uniform", "min_inclusive": 2, "max_inclusive": 5}}, {"type": "minecraft:in_square"},
        {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR_WG"}, {"type": "minecraft:biome"}]})


# ================================================================== NBT structure templates
ID = {'int': 3, 'str': 8, 'list': 9, 'compound': 10}


def _s(s):
    b = s.encode('utf-8')
    return struct.pack('>H', len(b)) + b


def enc(kind, v):
    if kind == 'int':
        return struct.pack('>i', v)
    if kind == 'str':
        return _s(v)
    if kind == 'list':
        ik, items = v
        return bytes([ID[ik]]) + struct.pack('>i', len(items)) + b''.join(enc(ik, i) for i in items)
    if kind == 'compound':
        out = b''
        for name, (k, val) in v.items():
            out += bytes([ID[k]]) + _s(name) + enc(k, val)
        return out + b'\x00'
    raise ValueError(kind)


class Template:
    def __init__(self, sx, sy, sz):
        self.size = (sx, sy, sz)
        self.cells = {}

    def set(self, x, y, z, name, props=None, nbt=None):
        if 0 <= x < self.size[0] and 0 <= y < self.size[1] and 0 <= z < self.size[2]:
            self.cells[(x, y, z)] = (name, tuple(sorted((props or {}).items())), nbt)

    def fill(self, x0, y0, z0, x1, y1, z1, name, props=None):
        for x in range(min(x0, x1), max(x0, x1) + 1):
            for y in range(min(y0, y1), max(y0, y1) + 1):
                for z in range(min(z0, z1), max(z0, z1) + 1):
                    self.set(x, y, z, name, props)

    def save(self, rel):
        palette, index, blocks = [], {}, []
        for (x, y, z), (name, props, nbt) in sorted(self.cells.items(), key=lambda kv: (kv[0][1], kv[0][0], kv[0][2])):
            key = (name, props)
            if key not in index:
                index[key] = len(palette)
                entry = {"Name": ('str', name)}
                if props:
                    entry["Properties"] = ('compound', {k: ('str', v) for k, v in props})
                palette.append(entry)
            b = {"pos": ('list', ('int', [x, y, z])), "state": ('int', index[key])}
            if nbt:
                b["nbt"] = ('compound', {k: ('str', v) for k, v in nbt.items()})
            blocks.append(b)
        root = {"DataVersion": ('int', 3955),
                "size": ('list', ('int', list(self.size))),
                "palette": ('list', ('compound', palette)),
                "blocks": ('list', ('compound', blocks)),
                "entities": ('list', ('compound', []))}
        data = bytes([10]) + _s('') + enc('compound', root)
        p = os.path.join(ROOT, W, 'structure', rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with gzip.GzipFile(p, 'wb', mtime=0) as f:
            f.write(data)


BR, LU, ST, SO = f'{W}:genesis_bricks', f'{W}:lumenite_block', f'{W}:genesis_stone', f'{W}:genesis_soil'
FOUND = 2  # foundation layers below the floor (start_height is -2 so they sit underground)


def chest(t, x, y, z, facing, table):
    t.set(x, y, z, 'minecraft:chest', {"facing": facing, "type": "single", "waterlogged": "false"},
          {"id": "minecraft:chest", "LootTable": f"{W}:chests/{table}"})


def build_obelisk():
    t = Template(9, FOUND + 18, 9)
    t.fill(0, 0, 0, 8, FOUND - 1, 8, ST)
    f = FOUND
    t.fill(0, f, 0, 8, f, 8, BR)
    for cx, cz in ((0, 0), (8, 0), (0, 8), (8, 8)):
        t.fill(cx, f + 1, cz, cx, f + 2, cz, LU)
    t.fill(2, f + 1, 2, 6, f + 2, 6, BR)
    t.fill(3, f + 3, 3, 5, f + 9, 5, BR)
    t.fill(3, f + 4, 3, 5, f + 4, 5, LU)
    t.fill(3, f + 8, 3, 5, f + 8, 5, LU)
    t.fill(4, f + 10, 4, 4, f + 15, 4, BR)
    t.fill(4, f + 12, 4, 4, f + 12, 4, LU)
    t.fill(4, f + 16, 4, 4, f + 17, 4, LU)
    chest(t, 4, f + 1, 7, "north", "obelisk")
    t.save('obelisk.nbt')


def build_ring():
    t = Template(21, FOUND + 9, 21)
    f = FOUND
    c = 10
    for x in range(21):
        for z in range(21):
            r = math.hypot(x - c, z - c)
            if r <= 10.5:
                t.fill(x, 0, z, x, f - 1, z, ST)
                t.set(x, f, z, BR if r >= 8.5 else ST)
    for k in range(8):
        a = k * math.pi / 4
        px, pz = c + int(round(9 * math.cos(a))), c + int(round(9 * math.sin(a)))
        t.fill(px, f + 1, pz, px + 1, f + 6, pz + 1, BR)
        t.fill(px, f + 7, pz, px + 1, f + 7, pz + 1, LU)
    t.fill(c - 1, f + 1, c - 1, c + 1, f + 1, c + 1, BR)
    for dx, dz in ((0, -2), (0, 2), (-2, 0), (2, 0)):
        t.set(c + dx, f + 1, c + dz, LU)
    chest(t, c, f + 2, c, "south", "ring")
    t.save('ring.nbt')


def build_tower():
    H = 29
    t = Template(9, FOUND + H, 9)
    f = FOUND
    t.fill(0, 0, 0, 8, f - 1, 8, ST)
    for y in range(0, 27):
        for x in range(9):
            for z in range(9):
                edge = x in (0, 8) or z in (0, 8)
                t.set(x, f + y, z, BR if edge else 'minecraft:air')
    for fy in (0, 9, 18, 26):
        for x in range(1, 8):
            for z in range(1, 8):
                if not (x == 4 and z == 1) or fy == 0:
                    t.set(x, f + fy, z, BR)
    for y in range(1, 26):
        t.set(4, f + y, 1, 'minecraft:ladder', {"facing": "south", "waterlogged": "false"})
    for wy in (4, 13, 22):
        for y in (wy, wy + 1):
            t.set(0, f + y, 4, 'minecraft:air')
            t.set(8, f + y, 4, 'minecraft:air')
            t.set(4, f + y, 8, 'minecraft:air')
    t.set(4, f + 1, 8, 'minecraft:air')
    t.set(4, f + 2, 8, 'minecraft:air')
    for fy in (0, 9, 18):
        for x, z in ((1, 7), (7, 7), (7, 1)):
            t.set(x, f + fy + 1, z, LU)
    for x in range(9):
        for z in range(9):
            if (x in (0, 8) or z in (0, 8)) and (x + z) % 2 == 0:
                t.set(x, f + 27, z, BR)
    chest(t, 6, f + 10, 6, "west", "tower")
    chest(t, 4, f + 27, 4, "south", "tower")
    t.save('tower.nbt')


def write_structures():
    build_obelisk()
    build_ring()
    build_tower()
    spec = {
        'obelisk': (["glow_plains", "lumen_forest", "crystal_wastes"], 14, 5, 1357911, 'none'),
        'ring': (["glow_plains", "crystal_wastes", "void_marsh"], 22, 8, 2468013, 'beard_thin'),
        'tower': (["lumen_forest", "void_marsh", "glow_plains"], 30, 10, 3141592, 'beard_thin'),
    }
    for name, (biomes, spacing, sep, salt, adapt) in spec.items():
        wj(W, f'worldgen/template_pool/{name}.json', {"fallback": "minecraft:empty", "elements": [{"weight": 1, "element": {
            "element_type": "minecraft:single_pool_element", "location": f"{W}:{name}",
            "processors": "minecraft:empty", "projection": "rigid"}}]})
        wj(W, f'worldgen/structure/{name}.json', {
            "type": "minecraft:jigsaw", "biomes": [f"{W}:{b}" for b in biomes], "step": "surface_structures",
            "spawn_overrides": {"monster": {"bounding_box": "full", "spawns": [spawn(f"{W}:void_stalker", 1, 1, 2)]}},
            "terrain_adaptation": adapt, "start_pool": f"{W}:{name}", "size": 1, "start_height": {"absolute": -FOUND},
            "project_start_to_heightmap": "WORLD_SURFACE_WG", "max_distance_from_center": 80, "use_expansion_hack": False})
        wj(W, f'worldgen/structure_set/{name}.json', {
            "structures": [{"structure": f"{W}:{name}", "weight": 1}],
            "placement": {"type": "minecraft:random_spread", "spacing": spacing, "separation": sep, "salt": salt}})


write_loot()
write_recipes()
write_tags()
write_dimension()
write_biomes()
write_features()
write_structures()
print("data generated")
